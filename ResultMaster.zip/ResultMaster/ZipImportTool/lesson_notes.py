import os
import json
import requests
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Length
import datetime

lesson_notes_bp = Blueprint('lesson_notes', __name__, url_prefix='/lesson-notes')

class LessonNoteForm(FlaskForm):
    topic = StringField('Lesson Topic', validators=[DataRequired(), Length(min=3, max=100)])
    submit = SubmitField('Generate Lesson Notes')

def generate_fallback_notes(topic):
    """
    Generate basic lesson notes when the API call fails, based on the standard Nigerian lesson plan format
    """
    # Get current date in format: 25th March 2025
    from datetime import datetime
    today = datetime.now()
    date_str = today.strftime("%-d{} %B %Y").format(
        "th" if 4 <= today.day <= 20 or 24 <= today.day <= 30 else
        {1: "st", 2: "nd", 3: "rd"}.get(today.day % 10, "th")
    )
    
    # Create a lesson plan in the Nigerian standard format with proper HTML formatting
    return f"""<p>Format of a lesson plan for secondary schools in Nigeria<br>
LESSON PLAN OF PILLARS OF THE NATION SCHOOLS,<br>
BENIN CITY, EDO STATE</p>

<p>Subject:        Computer Science<br>
Class:          JSS 2<br>
Duration:       40 minutes<br>
Date:           {date_str}<br>
Age:            12 years and above<br>
Topic:          {topic}<br>
Specific objectives:  at end the lesson, the students should be able to:<br>
1. Explain the concept of {topic} clearly<br>
2. Discuss the general features of {topic}<br>
3. Apply key formulas in {topic}<br>
4. Discuss functions and recalculation in the {topic} environment<br>
5. Draw the {topic} environment</p>

<p>Instruction Materials: Chalk, board, lap top and a chart showing {topic}</p>

<p>Instructional Techniques: Observation explanatory discussion, demonstration, question and answers</p>

<p>Entry behaviour: The students have learnt about related concepts in the previous lesson.</p>

<p>Set induction or test entry behaviour: Introduction of the topic to the students starting from the known to unknown.</p>

<table>
<tr>
  <th>Content development</th>
  <th>Teacher activities</th>
  <th>Students activities</th>
  <th>Instructional method</th>
</tr>
<tr>
  <td>Meaning of {topic}</td>
  <td>The teacher explains the meaning of {topic}, what it is and its applications</td>
  <td>The students listen as the teacher explains the meaning of {topic}</td>
  <td>Explanatory</td>
</tr>
<tr>
  <td>Features of {topic}</td>
  <td>The teacher discusses various features and components of {topic}</td>
  <td>The students take notes and observe the demonstration</td>
  <td>Demonstration</td>
</tr>
<tr>
  <td>Functions in {topic}</td>
  <td>The teacher explains various functions available in {topic} and how to use them</td>
  <td>The students observe and practice using these functions</td>
  <td>Practical</td>
</tr>
<tr>
  <td>Applications of {topic}</td>
  <td>The teacher demonstrates practical applications and real-world examples</td>
  <td>The students participate by suggesting other applications</td>
  <td>Discussion</td>
</tr>
</table>

<p><strong>Evaluation:</strong><br>
1. What is {topic}?<br>
2. List 3 important features of {topic}.<br>
3. Explain 2 practical applications of {topic}.</p>

<p><strong>Conclusion:</strong><br>
The teacher concludes by summarizing the key points about {topic} and assigns homework.</p>"""

def generate_student_notes(topic):
    """
    Generate comprehensive notes for students based on the lesson topic
    """
    # Get current date in format: 25th March 2025
    from datetime import datetime
    today = datetime.now()
    date_str = today.strftime("%-d{} %B %Y").format(
        "th" if 4 <= today.day <= 20 or 24 <= today.day <= 30 else
        {1: "st", 2: "nd", 3: "rd"}.get(today.day % 10, "th")
    )
    
    # Create a basic student note in case API fails
    return f"""<div class="student-notes">
    <h1 class="text-center">PILLARS OF THE NATION SCHOOLS</h1>
    <h2 class="text-center">STUDENT LESSON NOTES</h2>
    <h3 class="text-center">Computer Science</h3>
    
    <div class="lesson-header">
        <p><strong>Topic:</strong> {topic}</p>
        <p><strong>Date:</strong> {date_str}</p>
        <p><strong>Class:</strong> JSS 2</p>
    </div>
    
    <div class="lesson-content">
        <h4>1. Introduction to {topic}</h4>
        <p>{topic} is an important concept in Computer Science that involves understanding how data is processed, stored, and manipulated by computers.</p>
        
        <h4>2. Key Concepts</h4>
        <ul>
            <li>Understanding the basic principles of {topic}</li>
            <li>How {topic} is applied in real-world situations</li>
            <li>The importance of {topic} in modern computing</li>
        </ul>
        
        <h4>3. Practical Applications</h4>
        <p>In our daily life, we encounter {topic} in many ways:</p>
        <ul>
            <li>Mobile phone applications</li>
            <li>Computer programs and software</li>
            <li>Digital services we use everyday</li>
        </ul>
        
        <h4>4. Summary</h4>
        <p>{topic} is a fundamental concept that helps us understand how computers work and how we can use them to solve problems efficiently.</p>
        
        <h4>5. Practice Questions</h4>
        <ol>
            <li>What is {topic}?</li>
            <li>List three applications of {topic} in our daily lives.</li>
            <li>Explain how {topic} helps in solving computational problems.</li>
            <li>Why is {topic} important in today's digital world?</li>
        </ol>
    </div>
    
    <div class="lesson-footer">
        <p class="text-center">© Pillars of The Nation Schools, Benin City</p>
    </div>
</div>"""

def get_lesson_notes(topic, include_student_notes=False):
    """
    Get detailed lesson notes for a given topic using OpenRouter's API
    If include_student_notes is True, also generate comprehensive student notes
    """
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key:
        result = {
            "success": True,
            "content": generate_fallback_notes(topic)
        }
        if include_student_notes:
            result["student_notes"] = generate_student_notes(topic)
        return result
    
    url = "https://openrouter.ai/api/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://replit.com",
        "X-Title": "Pillars Of The Nation Schools"
    }
    
    # Get current date in format: 25th March 2025
    from datetime import datetime
    today = datetime.now()
    date_str = today.strftime("%-d{} %B %Y").format(
        "th" if 4 <= today.day <= 20 or 24 <= today.day <= 30 else
        {1: "st", 2: "nd", 3: "rd"}.get(today.day % 10, "th")
    )
    
    prompt = f"""You are a teacher's assistant at Pillars Of The Nation Schools in Nigeria. Generate a detailed lesson plan for the topic: {topic}.

Follow the Nigerian standard format for lesson plans EXACTLY as shown below. Use this exact format matching the indentation, spacing, and table layout, but use proper HTML formatting with <p>, <br>, <table>, <tr>, <th>, and <td> tags for rendering on a webpage:

<p>Format of a lesson plan for secondary schools in Nigeria<br>
LESSON PLAN OF PILLARS OF THE NATION SCHOOLS,<br>
BENIN CITY, EDO STATE</p>

<p>Subject:        Computer Science<br>
Class:          JSS 2<br>
Duration:       40 minutes<br>
Date:           {date_str}<br>
Age:            12 years and above<br>
Topic:          {topic}<br>
Specific objectives:  at end the lesson, the students should be able to:<br>
1. [First objective related to {topic}]<br>
2. [Second objective related to {topic}]<br>
3. [Third objective related to {topic}]<br>
4. [Fourth objective related to {topic}]<br>
5. [Fifth objective related to {topic}]</p>

<p>Instruction Materials: [List appropriate teaching materials for {topic}]</p>

<p>Instructional Techniques: [List appropriate teaching techniques for {topic}]</p>

<p>Entry behaviour: [Describe what students already know that relates to {topic}]</p>

<p>Set induction or test entry behaviour: [Describe how to introduce {topic}]</p>

<table>
<tr>
  <th>Content development</th>
  <th>Teacher activities</th>
  <th>Students activities</th>
  <th>Instructional method</th>
</tr>
<tr>
  <td>[Aspect 1 of {topic}]</td>
  <td>[What teacher does]</td>
  <td>[What students do]</td>
  <td>[Method used]</td>
</tr>
<tr>
  <td>[Aspect 2 of {topic}]</td>
  <td>[What teacher does]</td>
  <td>[What students do]</td>
  <td>[Method used]</td>
</tr>
<tr>
  <td>[Aspect 3 of {topic}]</td>
  <td>[What teacher does]</td>
  <td>[What students do]</td>
  <td>[Method used]</td>
</tr>
<tr>
  <td>[Aspect 4 of {topic}]</td>
  <td>[What teacher does]</td>
  <td>[What students do]</td>
  <td>[Method used]</td>
</tr>
</table>

<p><strong>Evaluation:</strong><br>
1. [First evaluation question about {topic}]<br>
2. [Second evaluation question about {topic}]<br>
3. [Third evaluation question about {topic}]</p>

<p><strong>Conclusion:</strong><br>
[Provide a conclusion summarizing key points about {topic}]</p>

Be sure to replace all placeholder text in square brackets with specific, detailed content about {topic}. Follow exactly the format in the screenshot I was provided but output proper HTML that will render correctly on a webpage.
"""
    
    # If student notes are requested, create a separate prompt for them
    student_notes_prompt = None
    if include_student_notes:
        student_notes_prompt = f"""You are a teacher at Pillars Of The Nation Schools in Nigeria. Generate comprehensive, easy-to-understand student notes for the topic: {topic}.

These notes will be given directly to students to help them learn and revise the material. Include the following sections:

1. A clear title and header with the school name (Pillars Of The Nation Schools, Benin City)
2. An introduction explaining what {topic} is and why it's important
3. Key concepts and definitions related to {topic}
4. Detailed explanations with examples where appropriate
5. Diagrams or illustrations described in text that could be added later
6. Practice questions and exercises for students to test their understanding
7. A summary or conclusion section

Format the notes in clean, readable HTML that is visually appealing and well-structured. Use appropriate headings, lists, and paragraphs.
"""
    
    data = {
        "model": "anthropic/claude-3-haiku:beta",  # Use Claude 3 Haiku as a fallback model (less expensive)
        "messages": [
            {"role": "system", "content": "You are a knowledgeable teaching assistant that provides comprehensive lesson notes and educational content."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 2000,
        "stream": False,
        "headers": {
            "HTTP-Referer": "https://replit.com",
            "X-Title": "Pillars Of The Nation Schools"
        }
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        # Log the request and response for debugging
        print(f"API Request URL: {url}")
        print(f"API Request Headers: {headers}")
        print(f"API Request Data: {data}")
        
        # Check if the response was successful
        if response.status_code != 200:
            print(f"API Response Error: Status {response.status_code}")
            print(f"API Response Content: {response.text}")
            
            # Log more detailed error for debugging
            try:
                error_json = response.json()
                print(f"Detailed API Error: {json.dumps(error_json, indent=2)}")
            except:
                print("Could not parse error response as JSON")
                
            # Return fallback notes instead of showing an error to the user
            result = {
                "success": True,
                "content": generate_fallback_notes(topic)
            }
            if include_student_notes:
                result["student_notes"] = generate_student_notes(topic)
            return result
            
        response_data = response.json()
        print(f"API Response Data: {response_data}")
        
        teacher_notes = None
        if "choices" in response_data and len(response_data["choices"]) > 0:
            teacher_notes = response_data["choices"][0]["message"]["content"]
        else:
            teacher_notes = generate_fallback_notes(topic)
        
        result = {
            "success": True,
            "content": teacher_notes
        }
        
        # If student notes were requested, make a second API call to get them
        if include_student_notes and student_notes_prompt:
            try:
                student_data = {
                    "model": "anthropic/claude-3-haiku:beta",
                    "messages": [
                        {"role": "system", "content": "You are an expert educator who creates clear, comprehensive student notes."},
                        {"role": "user", "content": student_notes_prompt}
                    ],
                    "temperature": 0.7,
                    "max_tokens": 2000,
                    "stream": False,
                    "headers": {
                        "HTTP-Referer": "https://replit.com",
                        "X-Title": "Pillars Of The Nation Schools"
                    }
                }
                
                student_response = requests.post(url, headers=headers, json=student_data, timeout=30)
                
                if student_response.status_code == 200:
                    student_response_data = student_response.json()
                    if "choices" in student_response_data and len(student_response_data["choices"]) > 0:
                        result["student_notes"] = student_response_data["choices"][0]["message"]["content"]
                    else:
                        result["student_notes"] = generate_student_notes(topic)
                else:
                    result["student_notes"] = generate_student_notes(topic)
            except:
                result["student_notes"] = generate_student_notes(topic)
        elif include_student_notes:
            result["student_notes"] = generate_student_notes(topic)
            
        return result
        
    except requests.RequestException as e:
        print(f"API Request Exception: {str(e)}")
        # Return fallback notes instead of an error
        result = {
            "success": True,
            "content": generate_fallback_notes(topic)
        }
        if include_student_notes:
            result["student_notes"] = generate_student_notes(topic)
        return result

@lesson_notes_bp.route('/', methods=['GET', 'POST'])
@login_required
def index():
    if current_user.role != 'teacher':
        flash('Access denied: Teacher privileges required.', 'danger')
        return redirect(url_for('login'))
    
    form = LessonNoteForm()
    notes = None
    student_notes = None
    topic = None
    error = None
    
    if form.validate_on_submit():
        topic = form.topic.data
        result = get_lesson_notes(topic, include_student_notes=True)
        
        if result.get("success", False):
            notes = result["content"]
            if "student_notes" in result:
                student_notes = result["student_notes"]
        else:
            error = result.get("error", "An unknown error occurred")
            flash(f'Error generating lesson notes: {error}', 'danger')
    
    return render_template('teacher/lesson_notes.html',
                          form=form,
                          notes=notes,
                          student_notes=student_notes,
                          topic=topic,
                          error=error,
                          now=datetime.datetime.now())

# Add a route to handle AJAX requests for lesson notes
@lesson_notes_bp.route('/api/generate', methods=['POST'])
@login_required
def generate_lesson_notes_api():
    if current_user.role != 'teacher':
        return jsonify({"success": False, "error": "Access denied: Teacher privileges required."})
    
    topic = request.json.get('topic', '')
    if not topic:
        return jsonify({"success": False, "error": "Topic is required"})
    
    include_student_notes = request.json.get('include_student_notes', True)
    result = get_lesson_notes(topic, include_student_notes=include_student_notes)
    return jsonify(result)