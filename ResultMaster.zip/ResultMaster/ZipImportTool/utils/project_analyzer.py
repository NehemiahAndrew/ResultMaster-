import os
import json
import re

def analyze_project_structure(project_path):
    """
    Analyzes a project directory to determine the technology stack,
    dependencies, and structure.
    
    Args:
        project_path (str): Path to the extracted project
        
    Returns:
        dict: Project information including tech stack, dependencies, etc.
    """
    project_info = {
        'name': os.path.basename(project_path),
        'tech_stack': [],
        'frameworks': [],
        'dependencies': [],
        'languages': [],
        'database': [],
        'file_structure': {},
        'project_type': 'unknown',
        'entry_points': [],
        'environment_variables': [],
        'config_files': [],
    }
    
    # Track files by extension
    file_extensions = {}
    total_files = 0
    
    # Scan all files in the project
    for root, dirs, files in os.walk(project_path):
        for file in files:
            total_files += 1
            file_path = os.path.join(root, file)
            relative_path = os.path.relpath(file_path, project_path)
            
            # Count file extensions
            _, ext = os.path.splitext(file)
            ext = ext.lower()
            if ext:
                file_extensions[ext] = file_extensions.get(ext, 0) + 1
            
            # Identify key files
            if file.lower() in ['package.json', 'package-lock.json', 'yarn.lock']:
                project_info['tech_stack'].append('Node.js')
                project_info['languages'].append('JavaScript')
                
                # Parse package.json for dependencies
                if file.lower() == 'package.json':
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            package_data = json.load(f)
                            
                            # Extract dependencies
                            all_deps = {}
                            if 'dependencies' in package_data:
                                all_deps.update(package_data['dependencies'])
                            if 'devDependencies' in package_data:
                                all_deps.update(package_data['devDependencies'])
                            
                            for dep, version in all_deps.items():
                                project_info['dependencies'].append(f"{dep}: {version}")
                            
                            # Check for common frameworks
                            frameworks = {
                                'react': 'React',
                                'vue': 'Vue.js',
                                'angular': 'Angular',
                                'express': 'Express.js',
                                'next': 'Next.js',
                                'nuxt': 'Nuxt.js',
                                'meteor': 'Meteor',
                                'gatsby': 'Gatsby',
                            }
                            
                            for dep in all_deps:
                                for key, framework in frameworks.items():
                                    if key in dep.lower():
                                        if framework not in project_info['frameworks']:
                                            project_info['frameworks'].append(framework)
                            
                            # Determine project type
                            if 'react' in all_deps:
                                project_info['project_type'] = 'node-react'
                            elif 'express' in all_deps:
                                project_info['project_type'] = 'node-express'
                            elif 'vue' in all_deps:
                                project_info['project_type'] = 'node-vue'
                            elif 'angular' in all_deps:
                                project_info['project_type'] = 'node-angular'
                            else:
                                project_info['project_type'] = 'node-js'
                            
                            # Identify entry points
                            if 'main' in package_data:
                                project_info['entry_points'].append(package_data['main'])
                    except Exception as e:
                        print(f"Error parsing package.json: {e}")
            
            elif file.lower() in ['requirements.txt', 'setup.py', 'pipfile', 'pyproject.toml']:
                project_info['tech_stack'].append('Python')
                project_info['languages'].append('Python')
                
                # Parse requirements.txt for dependencies
                if file.lower() == 'requirements.txt':
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            requirements = f.read().splitlines()
                            for req in requirements:
                                req = req.strip()
                                if req and not req.startswith('#'):
                                    project_info['dependencies'].append(req)
                                    
                                    # Check for common Python frameworks
                                    frameworks = {
                                        'django': 'Django',
                                        'flask': 'Flask',
                                        'fastapi': 'FastAPI',
                                        'pyramid': 'Pyramid',
                                        'tornado': 'Tornado',
                                        'sqlalchemy': 'SQLAlchemy',
                                    }
                                    
                                    for key, framework in frameworks.items():
                                        if key in req.lower():
                                            if framework not in project_info['frameworks']:
                                                project_info['frameworks'].append(framework)
                    except Exception as e:
                        print(f"Error parsing requirements.txt: {e}")
            
            elif file.lower() == 'manage.py':
                project_info['frameworks'].append('Django')
                project_info['project_type'] = 'python-django'
                project_info['entry_points'].append(relative_path)
            
            elif file.lower() == 'app.py' or file.lower() == 'wsgi.py':
                # Check if it's a Flask application
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if 'flask' in content.lower():
                            project_info['frameworks'].append('Flask')
                            project_info['project_type'] = 'python-flask'
                            project_info['entry_points'].append(relative_path)
                except Exception:
                    pass
            
            elif file.lower() == 'composer.json':
                project_info['tech_stack'].append('PHP')
                project_info['languages'].append('PHP')
                project_info['project_type'] = 'php'
                
                # Parse composer.json for dependencies
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        composer_data = json.load(f)
                        
                        # Extract dependencies
                        all_deps = {}
                        if 'require' in composer_data:
                            all_deps.update(composer_data['require'])
                        if 'require-dev' in composer_data:
                            all_deps.update(composer_data['require-dev'])
                        
                        for dep, version in all_deps.items():
                            project_info['dependencies'].append(f"{dep}: {version}")
                        
                        # Check for common PHP frameworks
                        frameworks = {
                            'laravel': 'Laravel',
                            'symfony': 'Symfony',
                            'yii': 'Yii',
                            'cakephp': 'CakePHP',
                            'codeigniter': 'CodeIgniter',
                            'zend': 'Zend Framework',
                            'wordpress': 'WordPress',
                        }
                        
                        for dep in all_deps:
                            for key, framework in frameworks.items():
                                if key in dep.lower():
                                    if framework not in project_info['frameworks']:
                                        project_info['frameworks'].append(framework)
                except Exception as e:
                    print(f"Error parsing composer.json: {e}")
            
            elif file.lower() in ['.env', '.env.example', '.env.sample']:
                project_info['config_files'].append(relative_path)
                
                # Try to extract environment variables
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        env_content = f.read().splitlines()
                        for line in env_content:
                            line = line.strip()
                            if line and not line.startswith('#') and '=' in line:
                                key = line.split('=')[0].strip()
                                project_info['environment_variables'].append(key)
                except Exception:
                    pass
            
            # Identify database technologies
            if file.lower() in ['database.yml', 'schema.rb', 'models.py']:
                # Check file content for database hints
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read().lower()
                        db_techs = {
                            'postgresql': 'PostgreSQL',
                            'mysql': 'MySQL',
                            'sqlite': 'SQLite',
                            'mongodb': 'MongoDB',
                            'redis': 'Redis',
                            'sqlserver': 'SQL Server',
                            'oracle': 'Oracle',
                        }
                        
                        for key, tech in db_techs.items():
                            if key in content:
                                if tech not in project_info['database']:
                                    project_info['database'].append(tech)
                except Exception:
                    pass
    
    # Analyze file extensions to determine languages
    if file_extensions:
        extension_map = {
            '.py': 'Python',
            '.js': 'JavaScript',
            '.ts': 'TypeScript',
            '.jsx': 'React JSX',
            '.tsx': 'React TSX',
            '.php': 'PHP',
            '.rb': 'Ruby',
            '.java': 'Java',
            '.cs': 'C#',
            '.go': 'Go',
            '.rs': 'Rust',
            '.swift': 'Swift',
            '.kt': 'Kotlin',
            '.html': 'HTML',
            '.css': 'CSS',
            '.scss': 'SCSS',
            '.less': 'LESS',
            '.xml': 'XML',
            '.json': 'JSON',
            '.md': 'Markdown',
            '.sql': 'SQL',
        }
        
        languages = {}
        
        for ext, count in file_extensions.items():
            lang = extension_map.get(ext)
            if lang:
                languages[lang] = languages.get(lang, 0) + count
        
        # Add detected languages that aren't already in the list
        for lang in languages:
            if lang not in project_info['languages']:
                project_info['languages'].append(lang)
    
    # Clean up duplicates and sort lists
    project_info['tech_stack'] = sorted(list(set(project_info['tech_stack'])))
    project_info['frameworks'] = sorted(list(set(project_info['frameworks'])))
    project_info['languages'] = sorted(list(set(project_info['languages'])))
    project_info['database'] = sorted(list(set(project_info['database'])))
    
    # Additional project analysis based on detected tech stack
    if not project_info['project_type'] or project_info['project_type'] == 'unknown':
        # Try to determine project type from frameworks and files
        if 'Django' in project_info['frameworks']:
            project_info['project_type'] = 'python-django'
        elif 'Flask' in project_info['frameworks']:
            project_info['project_type'] = 'python-flask'
        elif 'Laravel' in project_info['frameworks'] or 'PHP' in project_info['languages']:
            project_info['project_type'] = 'php'
        elif 'React' in project_info['frameworks']:
            project_info['project_type'] = 'node-react'
        elif 'Express.js' in project_info['frameworks']:
            project_info['project_type'] = 'node-express'
        elif 'Vue.js' in project_info['frameworks']:
            project_info['project_type'] = 'node-vue'
        elif 'Angular' in project_info['frameworks']:
            project_info['project_type'] = 'node-angular'
        elif 'Next.js' in project_info['frameworks']:
            project_info['project_type'] = 'node-next'
        elif 'Ruby on Rails' in project_info['frameworks']:
            project_info['project_type'] = 'ruby-rails'
        elif 'Python' in project_info['languages']:
            project_info['project_type'] = 'python'
        elif 'JavaScript' in project_info['languages'] or 'TypeScript' in project_info['languages']:
            project_info['project_type'] = 'node-js'
    
    # Generate file structure overview (limited to avoid too much information)
    project_info['file_structure'] = get_directory_structure(project_path, max_depth=3)
    
    return project_info

def get_directory_structure(path, max_depth=3, current_depth=0):
    """
    Get a simplified view of the directory structure
    
    Args:
        path (str): Path to examine
        max_depth (int): Maximum directory depth
        current_depth (int): Current directory depth
        
    Returns:
        dict: Directory structure
    """
    if current_depth > max_depth:
        return {"...": "..."}
    
    result = {}
    
    try:
        items = os.listdir(path)
        
        # Sort items - directories first, then files
        dirs = [item for item in items if os.path.isdir(os.path.join(path, item))]
        files = [item for item in items if os.path.isfile(os.path.join(path, item))]
        
        dirs.sort()
        files.sort()
        
        # Process directories
        for item in dirs:
            if item.startswith('.') or item in ['node_modules', 'venv', 'env', '.git', '__pycache__']:
                continue
            result[item + '/'] = get_directory_structure(
                os.path.join(path, item), 
                max_depth, 
                current_depth + 1
            )
        
        # Process files (limit to 10 per directory)
        file_count = 0
        for item in files:
            if file_count >= 10:
                result["..."] = "..."
                break
            result[item] = {}
            file_count += 1
    except Exception as e:
        print(f"Error reading directory {path}: {e}")
        result = {"error": str(e)}
    
    return result
