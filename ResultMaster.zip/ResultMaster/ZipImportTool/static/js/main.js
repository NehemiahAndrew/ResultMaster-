document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    feather.replace();

    // Handle file upload UI on index page
    const fileInput = document.getElementById('project_zip');
    if (fileInput) {
        const uploadForm = document.getElementById('upload-form');
        const fileInfo = document.getElementById('file-info');
        const fileName = document.getElementById('file-name');
        const removeFileBtn = document.getElementById('remove-file');
        const uploadBtn = document.getElementById('upload-btn');
        const uploadContainer = document.querySelector('.file-upload-container');

        fileInput.addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                fileName.textContent = this.files[0].name;
                fileInfo.classList.remove('d-none');
                uploadBtn.removeAttribute('disabled');
                uploadContainer.style.borderColor = '#28a745';
            } else {
                resetFileUpload();
            }
        });

        removeFileBtn.addEventListener('click', function() {
            fileInput.value = '';
            resetFileUpload();
        });

        // Drag and drop functionality
        uploadContainer.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('drag-over');
        });

        uploadContainer.addEventListener('dragleave', function(e) {
            this.classList.remove('drag-over');
        });

        uploadContainer.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('drag-over');
            
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                fileInput.files = e.dataTransfer.files;
                
                // Trigger change event
                const event = new Event('change');
                fileInput.dispatchEvent(event);
            }
        });

        function resetFileUpload() {
            fileInfo.classList.add('d-none');
            fileName.textContent = '';
            uploadBtn.setAttribute('disabled', 'disabled');
            uploadContainer.style.borderColor = '';
        }
    }

    // Handle file structure tree in analyze page
    const structureData = document.getElementById('structure-data');
    if (structureData) {
        const fileStructure = JSON.parse(structureData.textContent);
        const rootFolderContents = document.getElementById('root-folder-contents');
        
        if (rootFolderContents) {
            renderFileStructure(fileStructure, rootFolderContents);
        }
    }

    // Handle file explorer in analyze page
    const fileExplorerSection = document.getElementById('file-explorer');
    if (fileExplorerSection) {
        const fileList = document.getElementById('file-list');
        const backButton = document.getElementById('back-button');
        const currentPath = document.getElementById('current-path');
        const currentFile = document.getElementById('current-file');
        const fileContentDisplay = document.getElementById('file-content-display');
        
        let pathHistory = ['/'];
        
        // Initialize file explorer
        loadFileList('/');
        
        // Back button functionality
        backButton.addEventListener('click', function() {
            if (pathHistory.length > 1) {
                pathHistory.pop(); // Remove current path
                const previousPath = pathHistory[pathHistory.length - 1];
                loadFileList(previousPath, false); // Don't push to history
            }
        });
        
        function loadFileList(path, pushToHistory = true) {
            fetch(`/file-explorer?path=${encodeURIComponent(path)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update UI
                        currentPath.textContent = '/' + path;
                        
                        if (pushToHistory) {
                            pathHistory.push(path);
                        }
                        
                        // Enable/disable back button
                        backButton.disabled = pathHistory.length <= 1;
                        
                        if (data.is_file) {
                            // Display file content
                            currentFile.textContent = path.split('/').pop();
                            fileContentDisplay.innerHTML = `<pre>${escapeHtml(data.content)}</pre>`;
                        } else {
                            // Display directory contents
                            currentFile.textContent = 'No file selected';
                            fileContentDisplay.innerHTML = `
                                <div class="select-file-message">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                                    <p>Select a file to view its content</p>
                                </div>
                            `;
                            
                            // Render directory contents
                            fileList.innerHTML = '';
                            
                            data.items.forEach(item => {
                                const el = document.createElement('div');
                                el.className = `file-item-explorer ${item.is_dir ? 'folder' : 'file'}`;
                                
                                let icon;
                                if (item.is_dir) {
                                    icon = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-folder"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>';
                                } else {
                                    icon = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>';
                                }
                                
                                el.innerHTML = icon + escapeHtml(item.name);
                                
                                el.addEventListener('click', function() {
                                    if (item.is_dir) {
                                        loadFileList(item.path);
                                    } else {
                                        loadFileContent(item.path);
                                    }
                                });
                                
                                fileList.appendChild(el);
                            });
                        }
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    fileList.innerHTML = `<div class="alert alert-danger">Error loading files: ${error.message}</div>`;
                });
        }
        
        function loadFileContent(path) {
            fetch(`/file-explorer?path=${encodeURIComponent(path)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.is_file) {
                        // Display file content
                        currentFile.textContent = path.split('/').pop();
                        fileContentDisplay.innerHTML = `<pre>${escapeHtml(data.content)}</pre>`;
                    } else {
                        alert('Error: ' + (data.message || 'Failed to load file content'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    fileContentDisplay.innerHTML = `<div class="alert alert-danger">Error loading file: ${error.message}</div>`;
                });
        }
    }

    // Handle dependency installation
    const installDepsBtn = document.getElementById('install-dependencies');
    if (installDepsBtn) {
        const dependencyOutput = document.getElementById('dependency-output');
        const dependencyConsole = document.getElementById('dependency-console');
        const projectData = document.getElementById('project-data');
        const projectType = projectData ? projectData.dataset.projectType : '';
        
        installDepsBtn.addEventListener('click', function() {
            // Show console and set loading state
            dependencyOutput.classList.remove('d-none');
            dependencyConsole.innerHTML = 'Installing dependencies...\n';
            installDepsBtn.disabled = true;
            
            // Make AJAX request to install dependencies
            fetch('/install-dependencies', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `project_type=${encodeURIComponent(projectType)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    dependencyConsole.innerHTML += data.output + '\n\nDependencies installed successfully!';
                } else {
                    dependencyConsole.innerHTML += `Error: ${data.message}\n`;
                }
            })
            .catch(error => {
                dependencyConsole.innerHTML += `Error: ${error.message}\n`;
            })
            .finally(() => {
                installDepsBtn.disabled = false;
            });
        });
    }

    // Handle run project
    const runProjectBtn = document.getElementById('run-project-btn');
    if (runProjectBtn) {
        const runOutput = document.getElementById('run-output');
        const runConsole = document.getElementById('run-console');
        const appRunningInfo = document.getElementById('app-running-info');
        const appUrl = document.getElementById('app-url');
        const projectData = document.getElementById('project-data');
        const projectType = projectData ? projectData.dataset.projectType : '';
        
        runProjectBtn.addEventListener('click', function() {
            // Show console and set loading state
            runOutput.classList.remove('d-none');
            appRunningInfo.classList.add('d-none');
            runConsole.innerHTML = 'Starting application...\n';
            runProjectBtn.disabled = true;
            
            // Make AJAX request to run project
            fetch('/run-project', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `project_type=${encodeURIComponent(projectType)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    runConsole.innerHTML += data.output + '\n\nApplication started successfully!\n';
                    
                    // Show application URL
                    appRunningInfo.classList.remove('d-none');
                    const port = data.port || 5000;
                    const url = `http://${window.location.hostname}:${port}`;
                    appUrl.href = url;
                    appUrl.textContent = url;
                } else {
                    runConsole.innerHTML += `Error: ${data.message}\n`;
                }
            })
            .catch(error => {
                runConsole.innerHTML += `Error: ${error.message}\n`;
            })
            .finally(() => {
                runProjectBtn.disabled = false;
            });
        });
    }

    // Handle toolbar run button
    const runAppBtn = document.getElementById('run-app-btn');
    if (runAppBtn) {
        runAppBtn.addEventListener('click', function() {
            // Scroll to run section and click the run button
            document.getElementById('run-project').scrollIntoView();
            document.getElementById('run-project-btn').click();
        });
    }

    // Handle toolbar install dependencies button
    const installDepsToolbarBtn = document.getElementById('install-deps-btn');
    if (installDepsToolbarBtn) {
        installDepsToolbarBtn.addEventListener('click', function() {
            // Scroll to dependencies section and click the install button
            document.getElementById('dependencies').scrollIntoView();
            document.getElementById('install-dependencies').click();
        });
    }
});

// Helper functions
function renderFileStructure(structure, container) {
    // Iterate through the structure object
    for (const [key, value] of Object.entries(structure)) {
        const isFolder = key.endsWith('/');
        const itemName = isFolder ? key.slice(0, -1) : key;
        
        const item = document.createElement('div');
        item.className = `structure-item ${isFolder ? 'folder-item' : 'file-item'}`;
        
        if (isFolder) {
            const folderIcon = document.createElement('i');
            folderIcon.setAttribute('data-feather', 'folder');
            item.appendChild(folderIcon);
            
            const folderName = document.createElement('span');
            folderName.className = 'folder-name';
            folderName.textContent = itemName;
            folderName.addEventListener('click', function() {
                const contents = this.nextElementSibling;
                if (contents.style.display === 'none') {
                    contents.style.display = 'block';
                    folderIcon.setAttribute('data-feather', 'folder');
                } else {
                    contents.style.display = 'none';
                    folderIcon.setAttribute('data-feather', 'folder-plus');
                }
                feather.replace();
            });
            item.appendChild(folderName);
            
            const folderContents = document.createElement('div');
            folderContents.className = 'folder-contents';
            
            // Recursively render folder contents
            renderFileStructure(value, folderContents);
            
            item.appendChild(folderContents);
        } else {
            const fileIcon = document.createElement('i');
            fileIcon.setAttribute('data-feather', 'file');
            item.appendChild(fileIcon);
            
            const fileName = document.createElement('span');
            fileName.className = 'file-name';
            fileName.textContent = itemName;
            item.appendChild(fileName);
        }
        
        container.appendChild(item);
    }
    
    // Initialize Feather icons for the new elements
    feather.replace();
}

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
