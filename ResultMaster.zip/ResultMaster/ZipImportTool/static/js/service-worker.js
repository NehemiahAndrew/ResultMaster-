const CACHE_NAME = 'school-report-hub-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/login',
  '/admin/dashboard',
  '/static/css/style.css',
  '/static/css/login.css',
  '/static/css/dashboard.css',
  '/static/js/script.js',
  '/static/img/logo.svg',
  '/static/img/icon-192x192.png',
  '/static/img/icon-512x512.png',
  '/static/manifest.json'
];

// Install service worker and cache the assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(ASSETS_TO_CACHE);
      })
  );
});

// Activate the service worker
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch from cache first, then network
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Return cached response if found
        if (response) {
          return response;
        }
        return fetch(event.request).then(
          response => {
            // Check if we received a valid response
            if(!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clone the response
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        );
      })
      .catch(() => {
        // If both cache and network fail, show an offline page
        if (event.request.url.includes('/static/')) {
          return new Response('Resource not available offline');
        }
      })
  );
});