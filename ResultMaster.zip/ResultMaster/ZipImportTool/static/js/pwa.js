// Register service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/static/js/service-worker.js')
      .then(registration => {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      })
      .catch(error => {
        console.log('ServiceWorker registration failed: ', error);
      });
  });
}

// Add to home screen functionality
let deferredPrompt;
const addBtn = document.createElement('button');
addBtn.classList.add('add-to-home');
addBtn.style.display = 'none';
addBtn.textContent = 'Install App';

window.addEventListener('beforeinstallprompt', (e) => {
  // Prevent Chrome from showing the install prompt
  e.preventDefault();
  // Store the event so it can be triggered later
  deferredPrompt = e;
  // Show the install button
  setTimeout(() => {
    if (!localStorage.getItem('pwa-installed')) {
      addBtn.style.display = 'block';
      document.body.appendChild(addBtn);
    }
  }, 5000);
});

addBtn.addEventListener('click', (e) => {
  // Hide the install button
  addBtn.style.display = 'none';
  // Show the install prompt
  deferredPrompt.prompt();
  // Wait for the user to respond to the prompt
  deferredPrompt.userChoice.then((choiceResult) => {
    if (choiceResult.outcome === 'accepted') {
      console.log('User accepted the install prompt');
      localStorage.setItem('pwa-installed', 'true');
    } else {
      console.log('User dismissed the install prompt');
    }
    // Clear the deferredPrompt variable
    deferredPrompt = null;
  });
});