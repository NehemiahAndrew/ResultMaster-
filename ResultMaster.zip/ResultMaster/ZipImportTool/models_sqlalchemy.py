from db import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import Column, Integer, String, Float, ForeignKey, Text
from sqlalchemy.orm import relationship

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    role = Column(String(20), nullable=False)  # admin, teacher, parent
    email = Column(String(100), nullable=True)
    associated_id = Column(String(50), nullable=True)  # ID of related teacher/parent entity
    
    # Relationships
    classes = relationship("Class", back_populates="teacher", cascade="all, delete-orphan")
    subjects = relationship("Subject", back_populates="teacher", cascade="all, delete-orphan")
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.id)

class Class(db.Model):
    __tablename__ = 'classes'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50), nullable=False)
    teacher_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Relationships
    teacher = relationship("User", back_populates="classes")
    students = relationship("Student", back_populates="class_", cascade="all, delete-orphan")
    subjects = relationship("Subject", back_populates="class_", cascade="all, delete-orphan")

class Student(db.Model):
    __tablename__ = 'students'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    admission_no = Column(String(20), unique=True, nullable=False)
    gender = Column(String(10), nullable=True)
    class_id = Column(Integer, ForeignKey('classes.id'), nullable=True)
    parent_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    # Relationships
    class_ = relationship("Class", back_populates="students")
    scores = relationship("Score", back_populates="student", cascade="all, delete-orphan")
    psychomotors = relationship("Psychomotor", back_populates="student", cascade="all, delete-orphan")
    attendances = relationship("Attendance", back_populates="student", cascade="all, delete-orphan")

class Subject(db.Model):
    __tablename__ = 'subjects'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    teacher_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    class_id = Column(Integer, ForeignKey('classes.id'), nullable=True)
    
    # Relationships
    teacher = relationship("User", back_populates="subjects")
    class_ = relationship("Class", back_populates="subjects")
    scores = relationship("Score", back_populates="subject", cascade="all, delete-orphan")

class Score(db.Model):
    __tablename__ = 'scores'
    
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'), nullable=False)
    subject_id = Column(Integer, ForeignKey('subjects.id'), nullable=False)
    ca_test1 = Column(Float, default=0)
    ca_test2 = Column(Float, default=0)
    exam = Column(Float, default=0)
    term = Column(String(20), nullable=False)
    academic_session = Column(String(20), nullable=False)
    position = Column(Integer, nullable=True)
    grade = Column(String(2), nullable=True)
    
    # Relationships
    student = relationship("Student", back_populates="scores")
    subject = relationship("Subject", back_populates="scores")
    
    @property
    def total(self):
        return self.ca_test1 + self.ca_test2 + self.exam

class Psychomotor(db.Model):
    __tablename__ = 'psychomotors'
    
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'), nullable=False)
    term = Column(String(20), nullable=False)
    academic_session = Column(String(20), nullable=False)
    
    # Psychomotor domains
    club_society = Column(String(2), nullable=True)
    drawing_painting = Column(String(2), nullable=True)
    handwriting = Column(String(2), nullable=True)
    verbal_fluency = Column(String(2), nullable=True)
    games_sports = Column(String(2), nullable=True)
    computer = Column(String(2), nullable=True)
    
    # Character traits
    punctuality = Column(String(2), nullable=True)
    attendance = Column(String(2), nullable=True)
    reliability = Column(String(2), nullable=True)
    honesty = Column(String(2), nullable=True)
    relationship_others = Column(String(2), nullable=True)
    participation = Column(String(2), nullable=True)
    carrying_assignment = Column(String(2), nullable=True)
    class_attendance = Column(String(2), nullable=True)
    
    # Comments
    teacher_comment = Column(Text, nullable=True)
    head_teacher_comment = Column(Text, nullable=True)
    
    # Relationships
    student = relationship("Student", back_populates="psychomotors")

class Attendance(db.Model):
    __tablename__ = 'attendances'
    
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey('students.id'), nullable=False)
    term = Column(String(20), nullable=False)
    academic_session = Column(String(20), nullable=False)
    days_school_open = Column(Integer, default=0)
    days_present = Column(Integer, default=0)
    days_absent = Column(Integer, default=0)
    
    # Relationships
    student = relationship("Student", back_populates="attendances")