import os
import json
from flask import Flask
from models_sqlalchemy import User, Student, Class, Subject, Score, Psychomotor, Attendance
from db import db, init_db

# Create a minimal Flask app for database operations
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
init_db(app)

def load_json_data(file_path):
    """Load data from JSON file"""
    if not os.path.exists(file_path):
        return []
    
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        return []

def migrate_users():
    """Migrate users from JSON to PostgreSQL"""
    users_data = load_json_data('data/users.json')
    for user_data in users_data:
        # Check if user already exists in the database
        existing_user = User.query.filter_by(username=user_data.get('username')).first()
        if existing_user:
            continue
        
        # Create new user
        user = User(
            username=user_data.get('username'),
            password_hash=user_data.get('password_hash'),
            role=user_data.get('role'),
            email=user_data.get('email'),
            associated_id=user_data.get('associated_id')
        )
        db.session.add(user)
    
    db.session.commit()
    print(f"Migrated {len(users_data)} users to PostgreSQL")

def migrate_classes():
    """Migrate classes from JSON to PostgreSQL"""
    classes_data = load_json_data('data/classes.json')
    for class_data in classes_data:
        # Check if class already exists in the database
        existing_class = Class.query.filter_by(name=class_data.get('name')).first()
        if existing_class:
            continue
        
        # Create new class
        class_obj = Class(
            name=class_data.get('name'),
            teacher_id=int(class_data.get('teacher_id')) if class_data.get('teacher_id') else None
        )
        db.session.add(class_obj)
    
    db.session.commit()
    print(f"Migrated {len(classes_data)} classes to PostgreSQL")

def migrate_students():
    """Migrate students from JSON to PostgreSQL"""
    students_data = load_json_data('data/students.json')
    for student_data in students_data:
        # Check if student already exists in the database
        existing_student = Student.query.filter_by(admission_no=student_data.get('admission_no')).first()
        if existing_student:
            continue
        
        # Create new student
        student = Student(
            name=student_data.get('name'),
            admission_no=student_data.get('admission_no'),
            class_id=int(student_data.get('class_id')) if student_data.get('class_id') else None,
            gender=student_data.get('gender'),
            parent_id=int(student_data.get('parent_id')) if student_data.get('parent_id') else None
        )
        db.session.add(student)
    
    db.session.commit()
    print(f"Migrated {len(students_data)} students to PostgreSQL")

def migrate_subjects():
    """Migrate subjects from JSON to PostgreSQL"""
    subjects_data = load_json_data('data/subjects.json')
    for subject_data in subjects_data:
        # Check if subject already exists in the database
        existing_subject = Subject.query.filter_by(
            name=subject_data.get('name'),
            class_id=int(subject_data.get('class_id')) if subject_data.get('class_id') else None
        ).first()
        if existing_subject:
            continue
        
        # Create new subject
        subject = Subject(
            name=subject_data.get('name'),
            teacher_id=int(subject_data.get('teacher_id')) if subject_data.get('teacher_id') else None,
            class_id=int(subject_data.get('class_id')) if subject_data.get('class_id') else None
        )
        db.session.add(subject)
    
    db.session.commit()
    print(f"Migrated {len(subjects_data)} subjects to PostgreSQL")

def migrate_scores():
    """Migrate scores from JSON to PostgreSQL"""
    scores_data = load_json_data('data/scores.json')
    for score_data in scores_data:
        # Check if score already exists in the database
        existing_score = Score.query.filter_by(
            student_id=int(score_data.get('student_id')) if score_data.get('student_id') else None,
            subject_id=int(score_data.get('subject_id')) if score_data.get('subject_id') else None,
            term=score_data.get('term'),
            academic_session=score_data.get('academic_session')
        ).first()
        if existing_score:
            continue
        
        # Create new score
        score = Score(
            student_id=int(score_data.get('student_id')) if score_data.get('student_id') else None,
            subject_id=int(score_data.get('subject_id')) if score_data.get('subject_id') else None,
            ca_test1=float(score_data.get('ca_test1', 0)),
            ca_test2=float(score_data.get('ca_test2', 0)),
            exam=float(score_data.get('exam', 0)),
            term=score_data.get('term'),
            academic_session=score_data.get('academic_session'),
            position=int(score_data.get('position')) if score_data.get('position') else None,
            grade=score_data.get('grade')
        )
        db.session.add(score)
    
    db.session.commit()
    print(f"Migrated {len(scores_data)} scores to PostgreSQL")

def migrate_psychomotors():
    """Migrate psychomotors from JSON to PostgreSQL"""
    psychomotors_data = load_json_data('data/psychomotor.json')
    for psychomotor_data in psychomotors_data:
        # Check if psychomotor already exists in the database
        existing_psychomotor = Psychomotor.query.filter_by(
            student_id=int(psychomotor_data.get('student_id')) if psychomotor_data.get('student_id') else None,
            term=psychomotor_data.get('term'),
            academic_session=psychomotor_data.get('academic_session')
        ).first()
        if existing_psychomotor:
            continue
        
        # Create new psychomotor
        psychomotor = Psychomotor(
            student_id=int(psychomotor_data.get('student_id')) if psychomotor_data.get('student_id') else None,
            term=psychomotor_data.get('term'),
            academic_session=psychomotor_data.get('academic_session'),
            club_society=psychomotor_data.get('club_society'),
            drawing_painting=psychomotor_data.get('drawing_painting'),
            handwriting=psychomotor_data.get('handwriting'),
            verbal_fluency=psychomotor_data.get('verbal_fluency'),
            games_sports=psychomotor_data.get('games_sports'),
            computer=psychomotor_data.get('computer'),
            punctuality=psychomotor_data.get('punctuality'),
            attendance=psychomotor_data.get('attendance'),
            reliability=psychomotor_data.get('reliability'),
            honesty=psychomotor_data.get('honesty'),
            relationship_others=psychomotor_data.get('relationship_others'),
            participation=psychomotor_data.get('participation'),
            carrying_assignment=psychomotor_data.get('carrying_assignment'),
            class_attendance=psychomotor_data.get('class_attendance'),
            teacher_comment=psychomotor_data.get('teacher_comment'),
            head_teacher_comment=psychomotor_data.get('head_teacher_comment')
        )
        db.session.add(psychomotor)
    
    db.session.commit()
    print(f"Migrated {len(psychomotors_data)} psychomotors to PostgreSQL")

def migrate_attendances():
    """Migrate attendances from JSON to PostgreSQL"""
    attendances_data = load_json_data('data/attendance.json')
    for attendance_data in attendances_data:
        # Check if attendance already exists in the database
        existing_attendance = Attendance.query.filter_by(
            student_id=int(attendance_data.get('student_id')) if attendance_data.get('student_id') else None,
            term=attendance_data.get('term'),
            academic_session=attendance_data.get('academic_session')
        ).first()
        if existing_attendance:
            continue
        
        # Create new attendance
        attendance = Attendance(
            student_id=int(attendance_data.get('student_id')) if attendance_data.get('student_id') else None,
            term=attendance_data.get('term'),
            academic_session=attendance_data.get('academic_session'),
            days_school_open=int(attendance_data.get('days_school_open', 0)),
            days_present=int(attendance_data.get('days_present', 0)),
            days_absent=int(attendance_data.get('days_absent', 0))
        )
        db.session.add(attendance)
    
    db.session.commit()
    print(f"Migrated {len(attendances_data)} attendances to PostgreSQL")

def run_migration():
    """Run the complete migration"""
    print("Starting data migration from JSON to PostgreSQL...")
    
    # Migration order matters due to foreign key relationships
    migrate_users()
    migrate_classes()
    migrate_students()
    migrate_subjects()
    migrate_scores()
    migrate_psychomotors()
    migrate_attendances()
    
    print("Data migration completed successfully!")

if __name__ == "__main__":
    # Create database tables if they don't exist
    with app.app_context():
        db.create_all()
    
    # Run the migration
    run_migration()