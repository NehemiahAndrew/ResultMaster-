from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from flask_login import login_user, logout_user, login_required, current_user
from models_sqlalchemy import User
from app import app
from db import db
from werkzeug.security import generate_password_hash
import datetime

# Create blueprint
auth_bp = Blueprint('auth', __name__)

# Login form
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

# Register a default admin user if no users exist
def create_default_admin():
    user_count = User.query.count()
    if user_count == 0:
        admin = User(
            username="admin",
            role="admin",
            email="admin@school.com"
        )
        admin.set_password("admin123")
        db.session.add(admin)
        db.session.commit()
        print("Default admin user created")

# Register routes with Flask app
@app.route('/login', methods=['GET', 'POST'])
def login():
    # Create default admin if no users exist
    create_default_admin()
    
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin.dashboard'))
        elif current_user.role == 'teacher':
            return redirect(url_for('teacher.dashboard'))
        elif current_user.role == 'parent':
            return redirect(url_for('parent.dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        if user and user.check_password(form.password.data):
            login_user(user)
            
            next_page = request.args.get('next')
            if not next_page or not next_page.startswith('/'):
                if user.role == 'admin':
                    next_page = url_for('admin.dashboard')
                elif user.role == 'teacher':
                    next_page = url_for('teacher.dashboard')
                elif user.role == 'parent':
                    next_page = url_for('parent.dashboard')
            
            return redirect(next_page)
        else:
            flash('Invalid username or password.', 'danger')
    
    return render_template('login.html', form=form, now=datetime.datetime.now())

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Register blueprint with Flask app
app.register_blueprint(auth_bp)
