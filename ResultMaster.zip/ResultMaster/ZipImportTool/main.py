from app import app
import auth
import admin
import teacher
import parent
import lesson_notes
import os
from db import db
import migrate_data
from models_sqlalchemy import User

if __name__ == "__main__":
    # Create data directory for backward compatibility
    if not os.path.exists("data"):
        os.makedirs("data")
        
    # Ensure all necessary data files exist for backward compatibility
    data_files = [
        "users.json", "students.json", "classes.json", 
        "subjects.json", "scores.json", "psychomotor.json", 
        "attendance.json"
    ]
    
    for file in data_files:
        file_path = f"data/{file}"
        if not os.path.exists(file_path):
            with open(file_path, "w") as f:
                f.write("[]")
    
    # Ensure all database tables are created
    with app.app_context():
        db.create_all()
        
        # Check if we need to migrate data
        user_count = User.query.count()
        if user_count == 0:
            # Run data migration if the database is empty
            migrate_data.run_migration()
    
    app.run(host="0.0.0.0", port=5000, debug=True)
