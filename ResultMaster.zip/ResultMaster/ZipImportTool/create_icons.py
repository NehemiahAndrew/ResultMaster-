import cairosvg
import os

# Ensure the directory exists
os.makedirs('static/img', exist_ok=True)

# Convert SVG to PNGs of various sizes
sizes = [192, 512]
for size in sizes:
    cairosvg.svg2png(
        url='static/img/app-icon.svg',
        write_to=f'static/img/icon-{size}x{size}.png',
        output_width=size,
        output_height=size
    )

print(f"Successfully created icons of sizes: {sizes}")