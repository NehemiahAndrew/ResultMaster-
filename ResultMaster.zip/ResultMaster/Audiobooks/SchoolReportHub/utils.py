import os
import json
from datetime import datetime

# Utility functions for the application

def get_current_academic_session():
    """
    Return the current academic session based on the current date
    Format: "YYYY/YYYY+1"
    """
    current_date = datetime.now()
    current_month = current_date.month
    current_year = current_date.year
    
    # If we're in the second half of the calendar year (August-December)
    # we're in the first half of the academic year
    if current_month >= 8:
        return f"{current_year}/{current_year + 1}"
    # Otherwise, we're in the second half of the previous academic year
    else:
        return f"{current_year - 1}/{current_year}"

def get_current_term():
    """
    Return the current term based on the current date
    1st term: September - December
    2nd term: January - March
    3rd term: April - July
    """
    current_month = datetime.now().month
    
    if 9 <= current_month <= 12:
        return "1st"
    elif 1 <= current_month <= 3:
        return "2nd"
    else:
        return "3rd"

def calculate_grade(total):
    """Calculate grade based on total score"""
    if total >= 70:
        return 'A'
    elif total >= 60:
        return 'B'
    elif total >= 50:
        return 'C'
    elif total >= 45:
        return 'D'
    elif total >= 40:
        return 'E'
    else:
        return 'F'

def get_grade_remark(grade):
    """Return remark for a grade"""
    remarks = {
        'A': 'Excellent',
        'B': 'Very Good',
        'C': 'Good',
        'D': 'Fair',
        'E': 'Pass',
        'F': 'Fail'
    }
    return remarks.get(grade, '')

def get_psychomotor_rating_text(rating):
    """Convert numeric rating to text"""
    ratings = {
        '5': 'Excellent',
        '4': 'Very Good',
        '3': 'Good',
        '2': 'Fair',
        '1': 'Weak'
    }
    return ratings.get(rating, 'N/A')

def ensure_data_directory():
    """Make sure the data directory exists"""
    if not os.path.exists('data'):
        os.makedirs('data')
    
    # Create initial data files if they don't exist
    data_files = [
        "users.json", "students.json", "classes.json", 
        "subjects.json", "scores.json", "psychomotor.json", 
        "attendance.json"
    ]
    
    for file in data_files:
        file_path = f"data/{file}"
        if not os.path.exists(file_path):
            with open(file_path, "w") as f:
                f.write("[]")
