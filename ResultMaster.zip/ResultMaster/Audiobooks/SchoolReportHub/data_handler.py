import json
import os
from models import Student, Class, Subject, Score, Psychomotor, Attendance, User

class DataHandler:
    """
    Utility class for handling data operations
    """
    
    @staticmethod
    def get_all_academic_sessions():
        """Return all academic sessions from scores"""
        sessions = set()
        
        # Get from scores
        if os.path.exists('data/scores.json'):
            with open('data/scores.json', 'r') as f:
                try:
                    scores = json.load(f)
                    for score in scores:
                        if 'academic_session' in score:
                            sessions.add(score['academic_session'])
                except json.JSONDecodeError:
                    pass
        
        # Get from psychomotor
        if os.path.exists('data/psychomotor.json'):
            with open('data/psychomotor.json', 'r') as f:
                try:
                    psychomotors = json.load(f)
                    for psych in psychomotors:
                        if 'academic_session' in psych:
                            sessions.add(psych['academic_session'])
                except json.JSONDecodeError:
                    pass
        
        # Add current session if no sessions found
        if not sessions:
            sessions.add("2023/2024")
        
        return sorted(list(sessions))
    
    @staticmethod
    def get_class_average(class_id, term, academic_session):
        """Calculate class average for all subjects"""
        # Get all students in the class
        students = Student.get_all_students()
        class_students = [student for student in students if student.get('class_id') == class_id]
        
        if not class_students:
            return 0
        
        # Calculate average for each student
        total_average = 0
        student_count = 0
        
        for student in class_students:
            student_id = student.get('id')
            scores = Score.get_student_scores(student_id, term, academic_session)
            
            if scores:
                total = sum(int(score.ca_test1) + int(score.ca_test2) + int(score.exam) for score in scores)
                average = total / len(scores)
                total_average += average
                student_count += 1
        
        if student_count > 0:
            return round(total_average / student_count, 2)
        else:
            return 0
    
    @staticmethod
    def get_class_ranking(class_id, term, academic_session):
        """Calculate overall class ranking based on average scores"""
        # Get all students in the class
        students = Student.get_all_students()
        class_students = [student for student in students if student.get('class_id') == class_id]
        
        if not class_students:
            return {}
        
        # Calculate average for each student
        student_averages = []
        
        for student in class_students:
            student_id = student.get('id')
            scores = Score.get_student_scores(student_id, term, academic_session)
            
            if scores:
                total = sum(int(score.ca_test1) + int(score.ca_test2) + int(score.exam) for score in scores)
                average = total / len(scores)
                student_averages.append({
                    'student_id': student_id,
                    'average': average
                })
        
        # Sort by average (descending)
        student_averages.sort(key=lambda x: x['average'], reverse=True)
        
        # Assign rankings
        rankings = {}
        for i, student in enumerate(student_averages):
            rankings[student['student_id']] = i + 1
        
        return rankings
    
    @staticmethod
    def get_subject_scores_for_class(subject_id, class_id, term, academic_session):
        """Get all scores for a subject in a class"""
        # Get all students in the class
        students = Student.get_all_students()
        class_students = [student for student in students if student.get('class_id') == class_id]
        
        if not class_students:
            return []
        
        # Get scores for each student
        subject_scores = []
        
        for student in class_students:
            student_id = student.get('id')
            scores = Score.get_student_scores(student_id, term, academic_session)
            
            for score in scores:
                if score.subject_id == subject_id:
                    total = int(score.ca_test1) + int(score.ca_test2) + int(score.exam)
                    subject_scores.append({
                        'student_id': student_id,
                        'student_name': student.get('name'),
                        'score_id': score.id,
                        'ca_test1': score.ca_test1,
                        'ca_test2': score.ca_test2,
                        'exam': score.exam,
                        'total': total,
                        'grade': score.grade,
                        'position': score.position
                    })
                    break
        
        return subject_scores
    
    @staticmethod
    def get_subject_highest_score(subject_id, class_id, term, academic_session):
        """Get highest score for a subject in a class"""
        subject_scores = DataHandler.get_subject_scores_for_class(subject_id, class_id, term, academic_session)
        
        if not subject_scores:
            return 0
        
        return max(score['total'] for score in subject_scores)
    
    @staticmethod
    def get_subject_lowest_score(subject_id, class_id, term, academic_session):
        """Get lowest score for a subject in a class"""
        subject_scores = DataHandler.get_subject_scores_for_class(subject_id, class_id, term, academic_session)
        
        if not subject_scores:
            return 0
        
        return min(score['total'] for score in subject_scores)
    
    @staticmethod
    def get_subject_average_score(subject_id, class_id, term, academic_session):
        """Get average score for a subject in a class"""
        subject_scores = DataHandler.get_subject_scores_for_class(subject_id, class_id, term, academic_session)
        
        if not subject_scores:
            return 0
        
        total = sum(score['total'] for score in subject_scores)
        return round(total / len(subject_scores), 2)
    
    @staticmethod
    def get_class_size(class_id):
        """Get the number of students in a class"""
        students = Student.get_all_students()
        return len([student for student in students if student.get('class_id') == class_id])
