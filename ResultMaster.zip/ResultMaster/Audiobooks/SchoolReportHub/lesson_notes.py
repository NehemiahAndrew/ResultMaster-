import os
import json
import requests
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Length
import datetime

lesson_notes_bp = Blueprint('lesson_notes', __name__, url_prefix='/lesson-notes')

class LessonNoteForm(FlaskForm):
    topic = StringField('Lesson Topic', validators=[DataRequired(), Length(min=3, max=100)])
    submit = SubmitField('Generate Lesson Notes')

def generate_fallback_notes(topic):
    """
    Generate basic lesson notes when the API call fails, based on the standard Nigerian lesson plan format
    """
    # Get current date in format: 25th March 2025
    from datetime import datetime
    today = datetime.now()
    date_str = today.strftime("%-d{} %B %Y").format(
        "th" if 4 <= today.day <= 20 or 24 <= today.day <= 30 else
        {1: "st", 2: "nd", 3: "rd"}.get(today.day % 10, "th")
    )
    
    # Create a lesson plan in the Nigerian standard format
    return f"""# Format of a lesson plan for secondary schools in Nigeria

# LESSON PLAN OF PILLARS OF THE NATION SCHOOLS
# BENIN CITY, EDO STATE

**Subject:** Computer Science

**Class:** JSS 2

**Duration:** 40 minutes

**Date:** {date_str}

**Age:** 12 years and above

**Topic:** {topic}

**Specific objectives:** at end the lesson, the students should be able to:
1. Explain the concept of {topic} clearly
2. Discuss the importance of {topic}
3. List the key elements of {topic}
4. Describe how {topic} works in practice
5. Apply knowledge of {topic} to solve problems

**Instruction Materials:** Chalk, board, lap top and a chart showing {topic}

**Instructional Techniques:** Observation explanatory discussion, demonstration, question and answers

**Entry behaviour:** The students have learnt about related concepts in the previous lesson.

**Set induction or test entry behaviour:** Introduction of the topic to the students starting from the known to unknown.

| Content development | Teacher activities | Students activities | Instructional method |
|---------------------|-------------------|-------------------|----------------------|
| Definition of {topic} | The teacher explains the meaning of {topic} | The students listen as the teacher explains | Explanatory |
| Importance of {topic} | The teacher discusses why {topic} is important | The students take notes and ask questions | Discussion |
| Elements of {topic} | The teacher lists and explains the key elements | The students participate by answering questions | Question and Answer |
| Application of {topic} | The teacher demonstrates practical applications | The students observe and take notes | Demonstration |

**Evaluation:** 
1. What is {topic}?
2. List 3 importance of {topic}.
3. Explain 2 applications of {topic}.

**Conclusion:** 
The teacher concludes by summarizing the key points about {topic} and assigns homework.

Note: The AI-powered lesson notes generation feature is currently experiencing technical difficulties. This is a template format - for a complete lesson plan, please try again later or try a different topic."""

def get_lesson_notes(topic):
    """
    Get detailed lesson notes for a given topic using OpenRouter's API
    """
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key:
        return {
            "success": True,
            "content": generate_fallback_notes(topic)
        }
    
    url = "https://openrouter.ai/api/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://replit.com",
        "X-Title": "School Result Management System"
    }
    
    # Get current date in format: 25th March 2025
    from datetime import datetime
    today = datetime.now()
    date_str = today.strftime("%-d{} %B %Y").format(
        "th" if 4 <= today.day <= 20 or 24 <= today.day <= 30 else
        {1: "st", 2: "nd", 3: "rd"}.get(today.day % 10, "th")
    )
    
    prompt = f"""You are a teacher's assistant at Pillars Of The Nation Schools in Nigeria. Generate a detailed lesson plan for the topic: {topic}.

Follow the Nigerian standard format for lesson plans exactly as shown below:

# Format of a lesson plan for secondary schools in Nigeria

# LESSON PLAN OF PILLARS OF THE NATION SCHOOLS
# BENIN CITY, EDO STATE

**Subject:** Computer Science

**Class:** JSS 2

**Duration:** 40 minutes

**Date:** {date_str}

**Age:** 12 years and above

**Topic:** {topic}

**Specific objectives:** at end the lesson, the students should be able to:
1. [List 5 specific and measurable objectives related to {topic}]

**Instruction Materials:** [List appropriate teaching materials for {topic}]

**Instructional Techniques:** [List appropriate teaching techniques for {topic}]

**Entry behaviour:** [Describe what students already know that relates to {topic}]

**Set induction or test entry behaviour:** [Describe how to introduce {topic}]

| Content development | Teacher activities | Students activities | Instructional method |
|---------------------|-------------------|-------------------|----------------------|
| [Aspect 1 of {topic}] | [What teacher does] | [What students do] | [Method used] |
| [Aspect 2 of {topic}] | [What teacher does] | [What students do] | [Method used] |
| [Aspect 3 of {topic}] | [What teacher does] | [What students do] | [Method used] |
| [Aspect 4 of {topic}] | [What teacher does] | [What students do] | [Method used] |

**Evaluation:** 
[List 3-5 evaluation questions to assess student understanding of {topic}]

**Conclusion:** 
[Provide a conclusion summarizing key points about {topic}]

Be sure to replace all placeholder text in square brackets with specific, detailed content about {topic}.
"""
    
    data = {
        "model": "anthropic/claude-3-haiku:beta",  # Use Claude 3 Haiku as a fallback model (less expensive)
        "messages": [
            {"role": "system", "content": "You are a knowledgeable teaching assistant that provides comprehensive lesson notes and educational content."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 2000,
        "stream": False,
        "headers": {
            "HTTP-Referer": "https://replit.com",
            "X-Title": "School Result Management System"
        }
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        # Log the request and response for debugging
        print(f"API Request URL: {url}")
        print(f"API Request Headers: {headers}")
        print(f"API Request Data: {data}")
        
        # Check if the response was successful
        if response.status_code != 200:
            print(f"API Response Error: Status {response.status_code}")
            print(f"API Response Content: {response.text}")
            
            # Log more detailed error for debugging
            try:
                error_json = response.json()
                print(f"Detailed API Error: {json.dumps(error_json, indent=2)}")
            except:
                print("Could not parse error response as JSON")
                
            # Return fallback notes instead of showing an error to the user
            return {
                "success": True,
                "content": generate_fallback_notes(topic)
            }
            
        response_data = response.json()
        print(f"API Response Data: {response_data}")
        
        if "choices" in response_data and len(response_data["choices"]) > 0:
            return {
                "success": True,
                "content": response_data["choices"][0]["message"]["content"]
            }
        else:
            # Return fallback notes instead of an error
            return {
                "success": True,
                "content": generate_fallback_notes(topic)
            }
    except requests.RequestException as e:
        print(f"API Request Exception: {str(e)}")
        # Return fallback notes instead of an error
        return {
            "success": True,
            "content": generate_fallback_notes(topic)
        }

@lesson_notes_bp.route('/', methods=['GET', 'POST'])
@login_required
def index():
    if current_user.role != 'teacher':
        flash('Access denied: Teacher privileges required.', 'danger')
        return redirect(url_for('login'))
    
    form = LessonNoteForm()
    notes = None
    topic = None
    error = None
    
    if form.validate_on_submit():
        topic = form.topic.data
        result = get_lesson_notes(topic)
        
        if result.get("success", False):
            notes = result["content"]
        else:
            error = result.get("error", "An unknown error occurred")
            flash(f'Error generating lesson notes: {error}', 'danger')
    
    return render_template('teacher/lesson_notes.html',
                          form=form,
                          notes=notes,
                          topic=topic,
                          error=error,
                          now=datetime.datetime.now())

# Add a route to handle AJAX requests for lesson notes
@lesson_notes_bp.route('/api/generate', methods=['POST'])
@login_required
def generate_lesson_notes_api():
    if current_user.role != 'teacher':
        return jsonify({"success": False, "error": "Access denied: Teacher privileges required."})
    
    topic = request.json.get('topic', '')
    if not topic:
        return jsonify({"success": False, "error": "Topic is required"})
    
    result = get_lesson_notes(topic)
    return jsonify(result)