import io
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.units import inch, cm
from reportlab.pdfgen import canvas
from models import Student, Class, Subject, Score, Psychomotor, Attendance
from data_handler import DataHandler
import qrcode
from io import BytesIO
import base64

def generate_pdf(student_id, term, academic_session):
    """Generate PDF report card for a student"""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=50, leftMargin=50, topMargin=100, bottomMargin=50)
    
    # Get student data
    student = Student.get_by_id(student_id)
    if not student:
        return None
    
    # Get student class
    student_class = Class.get_by_id(student.class_id)
    class_name = student_class.name if student_class else "Unknown Class"
    
    # Get scores
    scores = Score.get_student_scores(student_id, term, academic_session)
    
    # Get subjects and create a dictionary with subject details
    subjects = Subject.get_all_subjects()
    subject_names = {subject.get('id'): subject.get('name') for subject in subjects}
    
    # Get psychomotor data
    psychomotor = Psychomotor.get_student_psychomotor(student_id, term, academic_session)
    
    # Get attendance data
    attendance = Attendance.get_student_attendance(student_id, term, academic_session)
    
    # Calculate totals and averages
    class_size = DataHandler.get_class_size(student.class_id)
    
    # Create QR code for verification (just a placeholder in this case)
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    verification_data = f"{student.name}_{term}_{academic_session}"
    qr.add_data(verification_data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")
    
    # Save QR code to BytesIO
    qr_buffer = BytesIO()
    qr_img.save(qr_buffer)
    qr_buffer.seek(0)
    qr_data = qr_buffer.read()
    qr_buffer.close()
    
    # Encode QR code to base64 for embedding
    qr_base64 = base64.b64encode(qr_data).decode('utf-8')
    
    # Create the PDF content
    elements = []
    
    # Styles
    styles = getSampleStyleSheet()
    header_style = styles['Heading1']
    subheader_style = styles['Heading2']
    normal_style = styles['Normal']
    
    # Custom styles
    title_style = ParagraphStyle(
        'Title',
        parent=styles['Heading1'],
        fontSize=16,
        alignment=1,
        spaceAfter=10
    )
    
    subtitle_style = ParagraphStyle(
        'Subtitle',
        parent=styles['Heading2'],
        fontSize=12,
        alignment=1,
        spaceAfter=5
    )
    
    # Create title
    elements.append(Paragraph("ROSE & PHILIPS ROYAL ACADEMY", title_style))
    elements.append(Paragraph("Motto: A Better Future Starts Here", subtitle_style))
    elements.append(Paragraph("25, Oshilon Street, Oshogbo, Benin City, Edo State, Nigeria", subtitle_style))
    elements.append(Paragraph("Telephone(s): 08026457183, 09076745469", subtitle_style))
    elements.append(Paragraph("Email Address: rosephilipsacademy@gmail.com", subtitle_style))
    elements.append(Spacer(1, 0.5*cm))
    
    # Add header text
    elements.append(Paragraph("FIRST TERM PERFORMANCE REPORT SHEET", title_style))
    elements.append(Spacer(1, 0.5*cm))
    
    # Student information table
    student_data = [
        ['Pupil\'s Name', student.name, 'Class', class_name],
        ['Class Population', str(class_size), 'Gender', student.gender],
        ['No of Subjects on Offer', str(len(scores)), 'Overall Grade', 'A'],
        ['Academic Session', academic_session, 'Term', term]
    ]
    
    student_table = Table(student_data, colWidths=[100, 150, 100, 150])
    student_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('BACKGROUND', (2, 0), (2, -1), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER')
    ]))
    
    elements.append(student_table)
    elements.append(Spacer(1, 0.5*cm))
    
    # Create scores table
    scores_data = [
        ['Subjects', 'CA Test 1', 'CA Test 2', 'Exam', 'Total', 'Subject Position', 'Grade', 'Remark'],
        ['', '20', '20', '60', '100', '', '', '']
    ]
    
    # Add scores for each subject
    for score in scores:
        subject_name = subject_names.get(score.subject_id, "Unknown Subject")
        total = int(score.ca_test1) + int(score.ca_test2) + int(score.exam)
        
        scores_data.append([
            subject_name, 
            str(score.ca_test1), 
            str(score.ca_test2), 
            str(score.exam), 
            str(total), 
            str(score.position) if score.position else "N/A", 
            score.grade, 
            "Fail" if score.grade == "F" else "Pass"
        ])
    
    # Calculate totals
    total_ca1 = sum(int(score.ca_test1) for score in scores)
    total_ca2 = sum(int(score.ca_test2) for score in scores)
    total_exam = sum(int(score.exam) for score in scores)
    total_score = total_ca1 + total_ca2 + total_exam
    
    # Add totals row
    scores_data.append([
        'Total', 
        str(total_ca1), 
        str(total_ca2), 
        str(total_exam), 
        str(total_score), 
        '', 
        '', 
        ''
    ])
    
    # Create scores table
    scores_table = Table(scores_data, colWidths=[100, 50, 50, 50, 50, 70, 50, 80])
    scores_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('BACKGROUND', (0, 1), (-1, 1), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER')
    ]))
    
    elements.append(scores_table)
    elements.append(Spacer(1, 0.5*cm))
    
    # Grade key
    grade_key = "Grade Keys: >=80 = \"A\", >=70 = \"B\", >=60 = \"C\", >=50 = \"D\", >=40 = \"E\", <40 = \"F\""
    elements.append(Paragraph(grade_key, normal_style))
    elements.append(Spacer(1, 0.5*cm))
    
    # Attendance table
    if attendance:
        attendance_data = [
            ['Attendance Table', '', ''],
            ['No of Times School Opened', str(attendance.days_school_open), ''],
            ['No of Times Present', str(attendance.days_present), ''],
            ['No of Times Absent', str(attendance.days_absent), '']
        ]
    else:
        attendance_data = [
            ['Attendance Table', '', ''],
            ['No of Times School Opened', '0', ''],
            ['No of Times Present', '0', ''],
            ['No of Times Absent', '0', '']
        ]
    
    # Session averages
    session_data = [
        ['Session Averages', '', ''],
        ['1st Term', '0.00', 'F'],
        ['2nd Term', '0.00', 'F'],
        ['3rd Term', '0.00', 'F'],
        ['Cumulative Average', '0.00', '']
    ]
    
    # Combine tables side by side
    attendance_table = Table([
        [Table(attendance_data, colWidths=[150, 50, 50]), Table(session_data, colWidths=[150, 50, 50])]
    ])
    
    elements.append(attendance_table)
    elements.append(Spacer(1, 0.5*cm))
    
    # Psychomotor and affective traits
    if psychomotor:
        psychomotor_data = [
            ['Psychomotor', 'Rating', 'Affective Traits', 'Rating'],
            ['Club/Society', psychomotor.club_society, 'Punctuality', psychomotor.punctuality],
            ['Drawing/Painting', psychomotor.drawing_painting, 'Attendance', psychomotor.attendance],
            ['Handwriting', psychomotor.handwriting, 'Reliability', psychomotor.reliability],
            ['Verbal Fluency', psychomotor.verbal_fluency, 'Honesty', psychomotor.honesty],
            ['Games/Sports', psychomotor.games_sports, 'Relationship With Others', psychomotor.relationship_others],
            ['Computer', psychomotor.computer, 'Participation', psychomotor.participation],
            ['', '', 'Carrying Out Assignments', psychomotor.carrying_assignment]
        ]
    else:
        psychomotor_data = [
            ['Psychomotor', 'Rating', 'Affective Traits', 'Rating'],
            ['Club/Society', '0', 'Punctuality', '0'],
            ['Drawing/Painting', '0', 'Attendance', '0'],
            ['Handwriting', '0', 'Reliability', '0'],
            ['Verbal Fluency', '0', 'Honesty', '0'],
            ['Games/Sports', '0', 'Relationship With Others', '0'],
            ['Computer', '0', 'Participation', '0'],
            ['', '', 'Carrying Out Assignments', '0']
        ]
    
    # Domain rating key
    domain_rating = "Domain Rating: 5 = \"Excellent\", 4 = \"Very Good\", 3 = \"Good\", 2 = \"Fair\", 1 = \"Weak\""
    
    # QR code placeholder
    qr_table_data = [['', f'<img src="data:image/png;base64,{qr_base64}" width="100" height="100"/>']]
    qr_table = Table(qr_table_data, colWidths=[280, 120])
    
    # Psychomotor table
    psychomotor_table = Table(psychomotor_data, colWidths=[100, 50, 150, 50])
    psychomotor_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER')
    ]))
    
    elements.append(psychomotor_table)
    elements.append(Spacer(1, 0.2*cm))
    elements.append(Paragraph(domain_rating, normal_style))
    elements.append(Spacer(1, 0.5*cm))
    
    # Comments section
    if psychomotor:
        teacher_comment = psychomotor.teacher_comment or ""
        head_teacher_comment = psychomotor.head_teacher_comment or ""
    else:
        teacher_comment = ""
        head_teacher_comment = ""
    
    comments_data = [
        ['Teacher\'s Comment', teacher_comment],
        ['Head-Teacher\'s Comment', head_teacher_comment],
        ['Next Term Begins', 'Monday, 18 September 2023']
    ]
    
    comments_table = Table(comments_data, colWidths=[150, 350])
    comments_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
    ]))
    
    elements.append(comments_table)
    elements.append(Spacer(1, 0.5*cm))
    
    # Signature line
    signature_data = [
        ['Signature, Stamp and Date', ''],
        ['Promoted To', '']
    ]
    
    signature_table = Table(signature_data, colWidths=[150, 350])
    signature_table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
    ]))
    
    elements.append(signature_table)
    
    # Disclaimer
    disclaimer = "Any alteration whatsoever on this document renders it invalid!"
    elements.append(Spacer(1, 0.5*cm))
    elements.append(Paragraph(disclaimer, ParagraphStyle('Disclaimer', parent=normal_style, alignment=1, fontStyle='italic')))
    
    # Build the PDF
    doc.build(elements)
    
    # Get the value of the BytesIO buffer
    pdf_bytes = buffer.getvalue()
    buffer.close()
    
    return pdf_bytes
