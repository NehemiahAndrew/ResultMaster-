from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField, PasswordField
from wtforms.validators import DataRequired, Email, ValidationError
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash
from models import User, Student, Class, Subject
from app import app
import json
import datetime

# Create blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# Forms
class ClassForm(FlaskForm):
    name = StringField('Class Name', validators=[DataRequired()])
    teacher_id = SelectField('Class Teacher', validators=[DataRequired()], coerce=str)
    submit = SubmitField('Submit')

class StudentForm(FlaskForm):
    name = StringField('Student Name', validators=[DataRequired()])
    admission_no = StringField('Admission Number', validators=[DataRequired()])
    gender = SelectField('Gender', choices=[('Male', 'Male'), ('Female', 'Female')])
    class_id = SelectField('Class', validators=[DataRequired()], coerce=str)
    parent_id = SelectField('Parent', validators=[DataRequired()], coerce=str)
    submit = SubmitField('Submit')

class SubjectForm(FlaskForm):
    name = StringField('Subject Name', validators=[DataRequired()])
    teacher_id = SelectField('Subject Teacher', validators=[DataRequired()], coerce=str)
    class_id = SelectField('Class', validators=[DataRequired()], coerce=str)
    submit = SubmitField('Submit')

class TeacherForm(FlaskForm):
    name = StringField('Teacher Name', validators=[DataRequired()])
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Submit')

class ParentForm(FlaskForm):
    name = StringField('Parent Name', validators=[DataRequired()])
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Submit')

# Routes
@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Count data for dashboard
    classes = Class.get_all_classes()
    students = Student.get_all_students()
    subjects = Subject.get_all_subjects()
    teachers = [user for user in User.get_all_users() if user.get('role') == 'teacher']
    parents = [user for user in User.get_all_users() if user.get('role') == 'parent']
    
    return render_template('admin/dashboard.html',
                         class_count=len(classes),
                         student_count=len(students),
                         subject_count=len(subjects),
                         teacher_count=len(teachers),
                         parent_count=len(parents),
                         now=datetime.datetime.now())

# Class Management
@admin_bp.route('/classes', methods=['GET', 'POST'])
@login_required
def manage_classes():
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get all teachers for the dropdown
    teachers = [user for user in User.get_all_users() if user.get('role') == 'teacher']
    teacher_choices = [(teacher.get('id'), teacher.get('username')) for teacher in teachers]
    teacher_choices.insert(0, ('', 'Select Teacher'))
    
    form = ClassForm()
    form.teacher_id.choices = teacher_choices
    
    if form.validate_on_submit():
        new_class = Class(
            name=form.name.data,
            teacher_id=form.teacher_id.data
        )
        new_class.save()
        flash('Class added successfully.', 'success')
        return redirect(url_for('admin.manage_classes'))
    
    classes = Class.get_all_classes()
    
    # Get teacher names for display
    teacher_names = {teacher.get('id'): teacher.get('username') for teacher in teachers}
    
    return render_template('admin/manage_classes.html', 
                          form=form, 
                          classes=classes,
                          teacher_names=teacher_names,
                          now=datetime.datetime.now())

@admin_bp.route('/classes/edit/<class_id>', methods=['GET', 'POST'])
@login_required
def edit_class(class_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get all teachers for the dropdown
    teachers = [user for user in User.get_all_users() if user.get('role') == 'teacher']
    teacher_choices = [(teacher.get('id'), teacher.get('username')) for teacher in teachers]
    teacher_choices.insert(0, ('', 'Select Teacher'))
    
    form = ClassForm()
    form.teacher_id.choices = teacher_choices
    
    class_obj = Class.get_by_id(class_id)
    
    if not class_obj:
        flash('Class not found.', 'danger')
        return redirect(url_for('admin.manage_classes'))
    
    if form.validate_on_submit():
        class_obj.name = form.name.data
        class_obj.teacher_id = form.teacher_id.data
        class_obj.save()
        flash('Class updated successfully.', 'success')
        return redirect(url_for('admin.manage_classes'))
    
    # Pre-populate the form with existing data
    form.name.data = class_obj.name
    form.teacher_id.data = class_obj.teacher_id
    
    return render_template('admin/manage_classes.html', 
                          form=form, 
                          edit=True,
                          class_id=class_id,
                          now=datetime.datetime.now())

@admin_bp.route('/classes/delete/<class_id>', methods=['POST'])
@login_required
def delete_class(class_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    classes = Class.get_all_classes()
    # Filter out the class to be deleted
    updated_classes = [cls for cls in classes if cls.get('id') != class_id]
    
    # Save the updated list back to the file
    with open('data/classes.json', 'w') as f:
        json.dump(updated_classes, f, indent=4)
    
    flash('Class deleted successfully.', 'success')
    return redirect(url_for('admin.manage_classes'))

# Student Management
@admin_bp.route('/students', methods=['GET', 'POST'])
@login_required
def manage_students():
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get all classes for the dropdown
    classes = Class.get_all_classes()
    class_choices = [(cls.get('id'), cls.get('name')) for cls in classes]
    class_choices.insert(0, ('', 'Select Class'))
    
    # Get all parents for the dropdown
    parents = [user for user in User.get_all_users() if user.get('role') == 'parent']
    parent_choices = [(parent.get('id'), parent.get('username')) for parent in parents]
    parent_choices.insert(0, ('', 'Select Parent'))
    
    form = StudentForm()
    form.class_id.choices = class_choices
    form.parent_id.choices = parent_choices
    
    if form.validate_on_submit():
        new_student = Student(
            name=form.name.data,
            admission_no=form.admission_no.data,
            gender=form.gender.data,
            class_id=form.class_id.data,
            parent_id=form.parent_id.data
        )
        new_student.save()
        flash('Student added successfully.', 'success')
        return redirect(url_for('admin.manage_students'))
    
    students = Student.get_all_students()
    
    # Get class names and parent names for display
    class_names = {cls.get('id'): cls.get('name') for cls in classes}
    parent_names = {parent.get('id'): parent.get('username') for parent in parents}
    
    return render_template('admin/manage_students.html', 
                          form=form, 
                          students=students,
                          class_names=class_names,
                          parent_names=parent_names,
                          now=datetime.datetime.now())

@admin_bp.route('/students/edit/<student_id>', methods=['GET', 'POST'])
@login_required
def edit_student(student_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get all classes for the dropdown
    classes = Class.get_all_classes()
    class_choices = [(cls.get('id'), cls.get('name')) for cls in classes]
    class_choices.insert(0, ('', 'Select Class'))
    
    # Get all parents for the dropdown
    parents = [user for user in User.get_all_users() if user.get('role') == 'parent']
    parent_choices = [(parent.get('id'), parent.get('username')) for parent in parents]
    parent_choices.insert(0, ('', 'Select Parent'))
    
    form = StudentForm()
    form.class_id.choices = class_choices
    form.parent_id.choices = parent_choices
    
    student = Student.get_by_id(student_id)
    
    if not student:
        flash('Student not found.', 'danger')
        return redirect(url_for('admin.manage_students'))
    
    if form.validate_on_submit():
        student.name = form.name.data
        student.admission_no = form.admission_no.data
        student.gender = form.gender.data
        student.class_id = form.class_id.data
        student.parent_id = form.parent_id.data
        student.save()
        flash('Student updated successfully.', 'success')
        return redirect(url_for('admin.manage_students'))
    
    # Pre-populate the form with existing data
    form.name.data = student.name
    form.admission_no.data = student.admission_no
    form.gender.data = student.gender
    form.class_id.data = student.class_id
    form.parent_id.data = student.parent_id
    
    return render_template('admin/manage_students.html', 
                          form=form, 
                          edit=True,
                          student_id=student_id,
                          now=datetime.datetime.now())

@admin_bp.route('/students/delete/<student_id>', methods=['POST'])
@login_required
def delete_student(student_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    students = Student.get_all_students()
    # Filter out the student to be deleted
    updated_students = [student for student in students if student.get('id') != student_id]
    
    # Save the updated list back to the file
    with open('data/students.json', 'w') as f:
        json.dump(updated_students, f, indent=4)
    
    flash('Student deleted successfully.', 'success')
    return redirect(url_for('admin.manage_students'))

# Subject Management
@admin_bp.route('/subjects', methods=['GET', 'POST'])
@login_required
def manage_subjects():
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get all teachers for the dropdown
    teachers = [user for user in User.get_all_users() if user.get('role') == 'teacher']
    teacher_choices = [(teacher.get('id'), teacher.get('username')) for teacher in teachers]
    teacher_choices.insert(0, ('', 'Select Teacher'))
    
    # Get all classes for the dropdown
    classes = Class.get_all_classes()
    class_choices = [(cls.get('id'), cls.get('name')) for cls in classes]
    class_choices.insert(0, ('', 'Select Class'))
    
    form = SubjectForm()
    form.teacher_id.choices = teacher_choices
    form.class_id.choices = class_choices
    
    if form.validate_on_submit():
        new_subject = Subject(
            name=form.name.data,
            teacher_id=form.teacher_id.data,
            class_id=form.class_id.data
        )
        new_subject.save()
        flash('Subject added successfully.', 'success')
        return redirect(url_for('admin.manage_subjects'))
    
    subjects = Subject.get_all_subjects()
    
    # Get teacher names and class names for display
    teacher_names = {teacher.get('id'): teacher.get('username') for teacher in teachers}
    class_names = {cls.get('id'): cls.get('name') for cls in classes}
    
    return render_template('admin/manage_subjects.html', 
                          form=form, 
                          subjects=subjects,
                          teacher_names=teacher_names,
                          class_names=class_names,
                          now=datetime.datetime.now())

@admin_bp.route('/subjects/edit/<subject_id>', methods=['GET', 'POST'])
@login_required
def edit_subject(subject_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get all teachers for the dropdown
    teachers = [user for user in User.get_all_users() if user.get('role') == 'teacher']
    teacher_choices = [(teacher.get('id'), teacher.get('username')) for teacher in teachers]
    teacher_choices.insert(0, ('', 'Select Teacher'))
    
    # Get all classes for the dropdown
    classes = Class.get_all_classes()
    class_choices = [(cls.get('id'), cls.get('name')) for cls in classes]
    class_choices.insert(0, ('', 'Select Class'))
    
    form = SubjectForm()
    form.teacher_id.choices = teacher_choices
    form.class_id.choices = class_choices
    
    subject = Subject.get_by_id(subject_id)
    
    if not subject:
        flash('Subject not found.', 'danger')
        return redirect(url_for('admin.manage_subjects'))
    
    if form.validate_on_submit():
        subject.name = form.name.data
        subject.teacher_id = form.teacher_id.data
        subject.class_id = form.class_id.data
        subject.save()
        flash('Subject updated successfully.', 'success')
        return redirect(url_for('admin.manage_subjects'))
    
    # Pre-populate the form with existing data
    form.name.data = subject.name
    form.teacher_id.data = subject.teacher_id
    form.class_id.data = subject.class_id
    
    return render_template('admin/manage_subjects.html', 
                          form=form, 
                          edit=True,
                          subject_id=subject_id,
                          now=datetime.datetime.now())

@admin_bp.route('/subjects/delete/<subject_id>', methods=['POST'])
@login_required
def delete_subject(subject_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    subjects = Subject.get_all_subjects()
    # Filter out the subject to be deleted
    updated_subjects = [subject for subject in subjects if subject.get('id') != subject_id]
    
    # Save the updated list back to the file
    with open('data/subjects.json', 'w') as f:
        json.dump(updated_subjects, f, indent=4)
    
    flash('Subject deleted successfully.', 'success')
    return redirect(url_for('admin.manage_subjects'))

# Teacher Management
@admin_bp.route('/teachers', methods=['GET', 'POST'])
@login_required
def manage_teachers():
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    form = TeacherForm()
    
    if form.validate_on_submit():
        # Check if username already exists
        existing_user = User.get_by_username(form.username.data)
        if existing_user:
            flash('Username already exists.', 'danger')
            return redirect(url_for('admin.manage_teachers'))
        
        # Create new teacher user
        new_teacher = User(
            username=form.username.data,
            email=form.email.data,
            role='teacher'
        )
        new_teacher.set_password(form.password.data)
        new_teacher.save()
        
        flash('Teacher added successfully.', 'success')
        return redirect(url_for('admin.manage_teachers'))
    
    # Get all teachers
    teachers = [user for user in User.get_all_users() if user.get('role') == 'teacher']
    
    return render_template('admin/manage_teachers.html', 
                          form=form, 
                          teachers=teachers,
                          now=datetime.datetime.now())

@admin_bp.route('/teachers/edit/<teacher_id>', methods=['GET', 'POST'])
@login_required
def edit_teacher(teacher_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    form = TeacherForm()
    
    teacher = User.get_by_id(teacher_id)
    
    if not teacher or teacher.role != 'teacher':
        flash('Teacher not found.', 'danger')
        return redirect(url_for('admin.manage_teachers'))
    
    if form.validate_on_submit():
        # Check if username already exists and it's not the current teacher
        existing_user = User.get_by_username(form.username.data)
        if existing_user and existing_user.id != teacher_id:
            flash('Username already exists.', 'danger')
            return redirect(url_for('admin.edit_teacher', teacher_id=teacher_id))
        
        teacher.username = form.username.data
        teacher.email = form.email.data
        
        # Only update password if provided
        if form.password.data:
            teacher.set_password(form.password.data)
        
        teacher.save()
        
        flash('Teacher updated successfully.', 'success')
        return redirect(url_for('admin.manage_teachers'))
    
    # Pre-populate the form with existing data
    form.username.data = teacher.username
    form.email.data = teacher.email
    
    return render_template('admin/manage_teachers.html', 
                          form=form, 
                          edit=True,
                          teacher_id=teacher_id,
                          now=datetime.datetime.now())

@admin_bp.route('/teachers/delete/<teacher_id>', methods=['POST'])
@login_required
def delete_teacher(teacher_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    users = User.get_all_users()
    # Filter out the teacher to be deleted
    updated_users = [user for user in users if user.get('id') != teacher_id]
    
    # Save the updated list back to the file
    with open('data/users.json', 'w') as f:
        json.dump(updated_users, f, indent=4)
    
    flash('Teacher deleted successfully.', 'success')
    return redirect(url_for('admin.manage_teachers'))

# Parent Management
@admin_bp.route('/parents', methods=['GET', 'POST'])
@login_required
def manage_parents():
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    form = ParentForm()
    
    if form.validate_on_submit():
        # Check if username already exists
        existing_user = User.get_by_username(form.username.data)
        if existing_user:
            flash('Username already exists.', 'danger')
            return redirect(url_for('admin.manage_parents'))
        
        # Create new parent user
        new_parent = User(
            username=form.username.data,
            email=form.email.data,
            role='parent'
        )
        new_parent.set_password(form.password.data)
        new_parent.save()
        
        flash('Parent added successfully.', 'success')
        return redirect(url_for('admin.manage_parents'))
    
    # Get all parents
    parents = [user for user in User.get_all_users() if user.get('role') == 'parent']
    
    return render_template('admin/manage_parents.html', 
                          form=form, 
                          parents=parents,
                          now=datetime.datetime.now())

@admin_bp.route('/parents/edit/<parent_id>', methods=['GET', 'POST'])
@login_required
def edit_parent(parent_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    form = ParentForm()
    
    parent = User.get_by_id(parent_id)
    
    if not parent or parent.role != 'parent':
        flash('Parent not found.', 'danger')
        return redirect(url_for('admin.manage_parents'))
    
    if form.validate_on_submit():
        # Check if username already exists and it's not the current parent
        existing_user = User.get_by_username(form.username.data)
        if existing_user and existing_user.id != parent_id:
            flash('Username already exists.', 'danger')
            return redirect(url_for('admin.edit_parent', parent_id=parent_id))
        
        parent.username = form.username.data
        parent.email = form.email.data
        
        # Only update password if provided
        if form.password.data:
            parent.set_password(form.password.data)
        
        parent.save()
        
        flash('Parent updated successfully.', 'success')
        return redirect(url_for('admin.manage_parents'))
    
    # Pre-populate the form with existing data
    form.username.data = parent.username
    form.email.data = parent.email
    
    return render_template('admin/manage_parents.html', 
                          form=form, 
                          edit=True,
                          parent_id=parent_id,
                          now=datetime.datetime.now())

@admin_bp.route('/parents/delete/<parent_id>', methods=['POST'])
@login_required
def delete_parent(parent_id):
    if current_user.role != 'admin':
        flash('Access denied: Admin privileges required.', 'danger')
        return redirect(url_for('login'))
    
    users = User.get_all_users()
    # Filter out the parent to be deleted
    updated_users = [user for user in users if user.get('id') != parent_id]
    
    # Save the updated list back to the file
    with open('data/users.json', 'w') as f:
        json.dump(updated_users, f, indent=4)
    
    flash('Parent deleted successfully.', 'success')
    return redirect(url_for('admin.manage_parents'))

# Register blueprint with Flask app
app.register_blueprint(admin_bp)
