from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, SelectMultipleField, HiddenField, SubmitField
from wtforms.validators import DataRequired, Length, Optional

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=50)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=4, max=50)])
    submit = SubmitField('Login')

class ClassForm(FlaskForm):
    class_id = HiddenField()
    name = StringField('Class Name', validators=[DataRequired(), Length(min=1, max=20)])
    section = StringField('Section', validators=[Length(max=10)])
    submit = SubmitField('Save')

class SubjectForm(FlaskForm):
    subject_id = HiddenField()
    name = StringField('Subject Name', validators=[DataRequired(), Length(min=2, max=50)])
    code = StringField('Subject Code', validators=[DataRequired(), Length(min=2, max=10)])
    submit = SubmitField('Save')

class StudentForm(FlaskForm):
    student_id = HiddenField()
    name = StringField('Student Name', validators=[DataRequired(), Length(min=3, max=100)])
    admission_no = StringField('Admission Number', validators=[DataRequired(), Length(min=3, max=20)])
    class_id = SelectField('Class', validators=[DataRequired()])
    gender = SelectField('Gender', choices=[('M', 'Male'), ('F', 'Female')])
    parent_id = StringField('Parent ID', validators=[Length(max=50)])
    submit = SubmitField('Save')

class TeacherForm(FlaskForm):
    teacher_id = HiddenField()
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=50)])
    password = PasswordField('Password', validators=[Length(min=4, max=50)])
    name = StringField('Full Name', validators=[DataRequired(), Length(min=3, max=100)])
    subject_ids = SelectMultipleField('Subjects', validators=[DataRequired()])
    class_ids = SelectMultipleField('Classes', validators=[DataRequired()])
    submit = SubmitField('Save')

class ScoreForm(FlaskForm):
    student_id = HiddenField()
    class_id = HiddenField()
    subject_id = HiddenField()
    term = HiddenField()
    session = HiddenField()
    ca1 = StringField('CA Test 1 (20)')
    ca2 = StringField('CA Test 2 (20)')
    exam = StringField('Exam (60)')
    comment = StringField('Remark')
    submit = SubmitField('Save Scores')

class PsychomotorForm(FlaskForm):
    student_id = HiddenField()
    class_id = HiddenField()
    term = HiddenField()
    session = HiddenField()
    
    # Psychomotor skills
    handwriting = SelectField('Handwriting', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    games_sports = SelectField('Games/Sports', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    handling_tools = SelectField('Handling Tools', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    drawing_painting = SelectField('Drawing/Painting', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    crafts = SelectField('Crafts', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    music = SelectField('Music', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    computer = SelectField('Computer', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    verbal_fluency = SelectField('Verbal Fluency', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    sports = SelectField('Sports', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    
    # Affective traits
    punctuality = SelectField('Punctuality', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    neatness = SelectField('Neatness', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    honesty = SelectField('Honesty', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    relationship = SelectField('Relationship with Others', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    leadership = SelectField('Leadership', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    attendance = SelectField('Attendance', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    participation = SelectField('Carrying Out Assignments', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    
    # Comments
    teacher_comment = StringField('Teacher\'s Comment')
    head_teacher_comment = StringField('Head Teacher\'s Comment')
    
    submit = SubmitField('Save')

class AttendanceForm(FlaskForm):
    student_id = HiddenField()
    class_id = HiddenField()
    term = HiddenField()
    session = HiddenField()
    days_school_opened = StringField('Days School Opened')
    days_present = StringField('Days Present')
    days_absent = StringField('Days Absent')
    submit = SubmitField('Save')

class FilterForm(FlaskForm):
    class_id = SelectField('Class', validators=[Optional()])
    subject_id = SelectField('Subject', validators=[Optional()])
    term = SelectField('Term', validators=[DataRequired()])
    session = SelectField('Session', validators=[DataRequired()])
    submit = SubmitField('Filter')
