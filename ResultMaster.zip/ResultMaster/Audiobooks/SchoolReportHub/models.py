import json
import os
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin):
    def __init__(self, id=None, username=None, password=None, role=None, email=None, associated_id=None):
        self.id = id
        self.username = username
        self.password_hash = password
        self.role = role  # admin, teacher, or parent
        self.email = email
        self.associated_id = associated_id  # teacher_id or parent_id (depending on role)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def save(self):
        users = self.get_all_users()
        
        # Check if user already exists
        for i, user in enumerate(users):
            if user.get('id') == self.id:
                # Update existing user
                users[i] = self.to_dict()
                break
        else:
            # Add new user
            if not self.id:
                self.id = str(len(users) + 1)
            users.append(self.to_dict())
        
        # Save to file
        with open('data/users.json', 'w') as f:
            json.dump([user for user in users], f, indent=4)
        
        return self

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'password_hash': self.password_hash,
            'role': self.role,
            'email': self.email,
            'associated_id': self.associated_id
        }

    @staticmethod
    def get_all_users():
        if not os.path.exists('data/users.json'):
            return []
        
        with open('data/users.json', 'r') as f:
            try:
                users = json.load(f)
                return users
            except json.JSONDecodeError:
                return []

    @staticmethod
    def get_by_username(username):
        users = User.get_all_users()
        for user_data in users:
            if user_data.get('username') == username:
                return User(
                    id=user_data.get('id'),
                    username=user_data.get('username'),
                    password=user_data.get('password_hash'),
                    role=user_data.get('role'),
                    email=user_data.get('email'),
                    associated_id=user_data.get('associated_id')
                )
        return None

    @staticmethod
    def get_by_id(user_id):
        users = User.get_all_users()
        for user_data in users:
            if user_data.get('id') == user_id:
                return User(
                    id=user_data.get('id'),
                    username=user_data.get('username'),
                    password=user_data.get('password_hash'),
                    role=user_data.get('role'),
                    email=user_data.get('email'),
                    associated_id=user_data.get('associated_id')
                )
        return None


class Student:
    def __init__(self, id=None, name=None, admission_no=None, class_id=None, gender=None, parent_id=None):
        self.id = id
        self.name = name
        self.admission_no = admission_no
        self.class_id = class_id
        self.gender = gender
        self.parent_id = parent_id

    def save(self):
        students = self.get_all_students()
        
        # Check if student already exists
        for i, student in enumerate(students):
            if student.get('id') == self.id:
                # Update existing student
                students[i] = self.to_dict()
                break
        else:
            # Add new student
            if not self.id:
                self.id = str(len(students) + 1)
            students.append(self.to_dict())
        
        # Save to file
        with open('data/students.json', 'w') as f:
            json.dump(students, f, indent=4)
        
        return self

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'admission_no': self.admission_no,
            'class_id': self.class_id,
            'gender': self.gender,
            'parent_id': self.parent_id
        }

    @staticmethod
    def get_all_students():
        if not os.path.exists('data/students.json'):
            return []
        
        with open('data/students.json', 'r') as f:
            try:
                students = json.load(f)
                return students
            except json.JSONDecodeError:
                return []

    @staticmethod
    def get_by_id(student_id):
        students = Student.get_all_students()
        for student_data in students:
            if student_data.get('id') == student_id:
                return Student(
                    id=student_data.get('id'),
                    name=student_data.get('name'),
                    admission_no=student_data.get('admission_no'),
                    class_id=student_data.get('class_id'),
                    gender=student_data.get('gender'),
                    parent_id=student_data.get('parent_id')
                )
        return None

    @staticmethod
    def get_by_parent_id(parent_id):
        students = Student.get_all_students()
        result = []
        for student_data in students:
            if student_data.get('parent_id') == parent_id:
                result.append(Student(
                    id=student_data.get('id'),
                    name=student_data.get('name'),
                    admission_no=student_data.get('admission_no'),
                    class_id=student_data.get('class_id'),
                    gender=student_data.get('gender'),
                    parent_id=student_data.get('parent_id')
                ))
        return result


class Class:
    def __init__(self, id=None, name=None, teacher_id=None):
        self.id = id
        self.name = name
        self.teacher_id = teacher_id

    def save(self):
        classes = self.get_all_classes()
        
        # Check if class already exists
        for i, cls in enumerate(classes):
            if cls.get('id') == self.id:
                # Update existing class
                classes[i] = self.to_dict()
                break
        else:
            # Add new class
            if not self.id:
                self.id = str(len(classes) + 1)
            classes.append(self.to_dict())
        
        # Save to file
        with open('data/classes.json', 'w') as f:
            json.dump(classes, f, indent=4)
        
        return self

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'teacher_id': self.teacher_id
        }

    @staticmethod
    def get_all_classes():
        if not os.path.exists('data/classes.json'):
            return []
        
        with open('data/classes.json', 'r') as f:
            try:
                classes = json.load(f)
                return classes
            except json.JSONDecodeError:
                return []

    @staticmethod
    def get_by_id(class_id):
        classes = Class.get_all_classes()
        for class_data in classes:
            if class_data.get('id') == class_id:
                return Class(
                    id=class_data.get('id'),
                    name=class_data.get('name'),
                    teacher_id=class_data.get('teacher_id')
                )
        return None


class Subject:
    def __init__(self, id=None, name=None, teacher_id=None, class_id=None):
        self.id = id
        self.name = name
        self.teacher_id = teacher_id
        self.class_id = class_id

    def save(self):
        subjects = self.get_all_subjects()
        
        # Check if subject already exists
        for i, subject in enumerate(subjects):
            if subject.get('id') == self.id:
                # Update existing subject
                subjects[i] = self.to_dict()
                break
        else:
            # Add new subject
            if not self.id:
                self.id = str(len(subjects) + 1)
            subjects.append(self.to_dict())
        
        # Save to file
        with open('data/subjects.json', 'w') as f:
            json.dump(subjects, f, indent=4)
        
        return self

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'teacher_id': self.teacher_id,
            'class_id': self.class_id
        }

    @staticmethod
    def get_all_subjects():
        if not os.path.exists('data/subjects.json'):
            return []
        
        with open('data/subjects.json', 'r') as f:
            try:
                subjects = json.load(f)
                return subjects
            except json.JSONDecodeError:
                return []

    @staticmethod
    def get_by_id(subject_id):
        subjects = Subject.get_all_subjects()
        for subject_data in subjects:
            if subject_data.get('id') == subject_id:
                return Subject(
                    id=subject_data.get('id'),
                    name=subject_data.get('name'),
                    teacher_id=subject_data.get('teacher_id'),
                    class_id=subject_data.get('class_id')
                )
        return None


class Score:
    def __init__(self, id=None, student_id=None, subject_id=None, ca_test1=0, ca_test2=0, exam=0, 
                 term=None, academic_session=None, position=None, grade=None):
        self.id = id
        self.student_id = student_id
        self.subject_id = subject_id
        self.ca_test1 = ca_test1
        self.ca_test2 = ca_test2
        self.exam = exam
        self.term = term
        self.academic_session = academic_session
        self.position = position
        self.grade = grade

    def save(self):
        scores = self.get_all_scores()
        
        # Check if score already exists
        for i, score in enumerate(scores):
            if (score.get('student_id') == self.student_id and 
                score.get('subject_id') == self.subject_id and
                score.get('term') == self.term and
                score.get('academic_session') == self.academic_session):
                # Update existing score
                self.id = score.get('id')
                scores[i] = self.to_dict()
                break
        else:
            # Add new score
            if not self.id:
                self.id = str(len(scores) + 1)
            scores.append(self.to_dict())
        
        # Save to file
        with open('data/scores.json', 'w') as f:
            json.dump(scores, f, indent=4)
        
        return self

    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'subject_id': self.subject_id,
            'ca_test1': self.ca_test1,
            'ca_test2': self.ca_test2,
            'exam': self.exam,
            'term': self.term,
            'academic_session': self.academic_session,
            'position': self.position,
            'grade': self.grade
        }

    @staticmethod
    def get_all_scores():
        if not os.path.exists('data/scores.json'):
            return []
        
        with open('data/scores.json', 'r') as f:
            try:
                scores = json.load(f)
                return scores
            except json.JSONDecodeError:
                return []

    @staticmethod
    def get_student_scores(student_id, term, academic_session):
        scores = Score.get_all_scores()
        result = []
        for score_data in scores:
            if (score_data.get('student_id') == student_id and 
                score_data.get('term') == term and
                score_data.get('academic_session') == academic_session):
                result.append(Score(
                    id=score_data.get('id'),
                    student_id=score_data.get('student_id'),
                    subject_id=score_data.get('subject_id'),
                    ca_test1=score_data.get('ca_test1'),
                    ca_test2=score_data.get('ca_test2'),
                    exam=score_data.get('exam'),
                    term=score_data.get('term'),
                    academic_session=score_data.get('academic_session'),
                    position=score_data.get('position'),
                    grade=score_data.get('grade')
                ))
        return result


class Psychomotor:
    def __init__(self, id=None, student_id=None, term=None, academic_session=None, 
                 club_society=None, drawing_painting=None, handwriting=None, 
                 verbal_fluency=None, games_sports=None, computer=None, 
                 punctuality=None, attendance=None, reliability=None, 
                 honesty=None, relationship_others=None, participation=None, 
                 carrying_assignment=None, class_attendance=None, teacher_comment=None, 
                 head_teacher_comment=None):
        self.id = id
        self.student_id = student_id
        self.term = term
        self.academic_session = academic_session
        self.club_society = club_society
        self.drawing_painting = drawing_painting
        self.handwriting = handwriting
        self.verbal_fluency = verbal_fluency
        self.games_sports = games_sports
        self.computer = computer
        self.punctuality = punctuality
        self.attendance = attendance
        self.reliability = reliability
        self.honesty = honesty
        self.relationship_others = relationship_others
        self.participation = participation
        self.carrying_assignment = carrying_assignment
        self.class_attendance = class_attendance
        self.teacher_comment = teacher_comment
        self.head_teacher_comment = head_teacher_comment

    def save(self):
        psychomotors = self.get_all_psychomotors()
        
        # Check if psychomotor already exists
        for i, psychomotor in enumerate(psychomotors):
            if (psychomotor.get('student_id') == self.student_id and 
                psychomotor.get('term') == self.term and
                psychomotor.get('academic_session') == self.academic_session):
                # Update existing psychomotor
                self.id = psychomotor.get('id')
                psychomotors[i] = self.to_dict()
                break
        else:
            # Add new psychomotor
            if not self.id:
                self.id = str(len(psychomotors) + 1)
            psychomotors.append(self.to_dict())
        
        # Save to file
        with open('data/psychomotor.json', 'w') as f:
            json.dump(psychomotors, f, indent=4)
        
        return self

    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'term': self.term,
            'academic_session': self.academic_session,
            'club_society': self.club_society,
            'drawing_painting': self.drawing_painting,
            'handwriting': self.handwriting,
            'verbal_fluency': self.verbal_fluency,
            'games_sports': self.games_sports,
            'computer': self.computer,
            'punctuality': self.punctuality,
            'attendance': self.attendance,
            'reliability': self.reliability,
            'honesty': self.honesty,
            'relationship_others': self.relationship_others,
            'participation': self.participation,
            'carrying_assignment': self.carrying_assignment,
            'class_attendance': self.class_attendance,
            'teacher_comment': self.teacher_comment,
            'head_teacher_comment': self.head_teacher_comment
        }

    @staticmethod
    def get_all_psychomotors():
        if not os.path.exists('data/psychomotor.json'):
            return []
        
        with open('data/psychomotor.json', 'r') as f:
            try:
                psychomotors = json.load(f)
                return psychomotors
            except json.JSONDecodeError:
                return []

    @staticmethod
    def get_student_psychomotor(student_id, term, academic_session):
        psychomotors = Psychomotor.get_all_psychomotors()
        for psychomotor_data in psychomotors:
            if (psychomotor_data.get('student_id') == student_id and 
                psychomotor_data.get('term') == term and
                psychomotor_data.get('academic_session') == academic_session):
                return Psychomotor(
                    id=psychomotor_data.get('id'),
                    student_id=psychomotor_data.get('student_id'),
                    term=psychomotor_data.get('term'),
                    academic_session=psychomotor_data.get('academic_session'),
                    club_society=psychomotor_data.get('club_society'),
                    drawing_painting=psychomotor_data.get('drawing_painting'),
                    handwriting=psychomotor_data.get('handwriting'),
                    verbal_fluency=psychomotor_data.get('verbal_fluency'),
                    games_sports=psychomotor_data.get('games_sports'),
                    computer=psychomotor_data.get('computer'),
                    punctuality=psychomotor_data.get('punctuality'),
                    attendance=psychomotor_data.get('attendance'),
                    reliability=psychomotor_data.get('reliability'),
                    honesty=psychomotor_data.get('honesty'),
                    relationship_others=psychomotor_data.get('relationship_others'),
                    participation=psychomotor_data.get('participation'),
                    carrying_assignment=psychomotor_data.get('carrying_assignment'),
                    class_attendance=psychomotor_data.get('class_attendance'),
                    teacher_comment=psychomotor_data.get('teacher_comment'),
                    head_teacher_comment=psychomotor_data.get('head_teacher_comment')
                )
        return None


class Attendance:
    def __init__(self, id=None, student_id=None, term=None, academic_session=None, 
                 days_school_open=0, days_present=0, days_absent=0):
        self.id = id
        self.student_id = student_id
        self.term = term
        self.academic_session = academic_session
        self.days_school_open = days_school_open
        self.days_present = days_present
        self.days_absent = days_absent

    def save(self):
        attendances = self.get_all_attendances()
        
        # Check if attendance already exists
        for i, attendance in enumerate(attendances):
            if (attendance.get('student_id') == self.student_id and 
                attendance.get('term') == self.term and
                attendance.get('academic_session') == self.academic_session):
                # Update existing attendance
                self.id = attendance.get('id')
                attendances[i] = self.to_dict()
                break
        else:
            # Add new attendance
            if not self.id:
                self.id = str(len(attendances) + 1)
            attendances.append(self.to_dict())
        
        # Save to file
        with open('data/attendance.json', 'w') as f:
            json.dump(attendances, f, indent=4)
        
        return self

    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'term': self.term,
            'academic_session': self.academic_session,
            'days_school_open': self.days_school_open,
            'days_present': self.days_present,
            'days_absent': self.days_absent
        }

    @staticmethod
    def get_all_attendances():
        if not os.path.exists('data/attendance.json'):
            return []
        
        with open('data/attendance.json', 'r') as f:
            try:
                attendances = json.load(f)
                return attendances
            except json.JSONDecodeError:
                return []

    @staticmethod
    def get_student_attendance(student_id, term, academic_session):
        attendances = Attendance.get_all_attendances()
        for attendance_data in attendances:
            if (attendance_data.get('student_id') == student_id and 
                attendance_data.get('term') == term and
                attendance_data.get('academic_session') == academic_session):
                return Attendance(
                    id=attendance_data.get('id'),
                    student_id=attendance_data.get('student_id'),
                    term=attendance_data.get('term'),
                    academic_session=attendance_data.get('academic_session'),
                    days_school_open=attendance_data.get('days_school_open'),
                    days_present=attendance_data.get('days_present'),
                    days_absent=attendance_data.get('days_absent')
                )
        return None
