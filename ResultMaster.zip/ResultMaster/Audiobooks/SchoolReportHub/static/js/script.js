document.addEventListener('DOMContentLoaded', function() {
    // Flash message auto-dismiss
    const flashMessages = document.querySelectorAll('.alert');
    flashMessages.forEach(function(message) {
        setTimeout(function() {
            message.classList.add('fade');
            setTimeout(function() {
                message.remove();
            }, 500);
        }, 5000);
    });

    // Add event listeners for the filter forms
    const filterForms = document.querySelectorAll('.filter-form');
    filterForms.forEach(function(form) {
        const selects = form.querySelectorAll('select');
        selects.forEach(function(select) {
            select.addEventListener('change', function() {
                form.submit();
            });
        });
    });

    // Score input validation
    const scoreInputs = document.querySelectorAll('.score-input');
    scoreInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            const value = parseInt(this.value);
            const max = parseInt(this.getAttribute('max'));
            
            if (isNaN(value)) {
                this.value = '';
            } else if (value < 0) {
                this.value = 0;
            } else if (value > max) {
                this.value = max;
            }
        });
    });

    // Calculate total score from CA test and exam scores
    const caTest1Inputs = document.querySelectorAll('.ca-test1');
    const caTest2Inputs = document.querySelectorAll('.ca-test2');
    const examInputs = document.querySelectorAll('.exam');
    const totalScores = document.querySelectorAll('.total-score');

    function updateTotal(index) {
        const ca1 = parseInt(caTest1Inputs[index].value) || 0;
        const ca2 = parseInt(caTest2Inputs[index].value) || 0;
        const exam = parseInt(examInputs[index].value) || 0;
        const total = ca1 + ca2 + exam;
        totalScores[index].textContent = total;

        // Update the grade based on the total score
        const gradeElement = document.querySelectorAll('.grade')[index];
        if (gradeElement) {
            let grade = 'F';
            if (total >= 70) grade = 'A';
            else if (total >= 60) grade = 'B';
            else if (total >= 50) grade = 'C';
            else if (total >= 45) grade = 'D';
            else if (total >= 40) grade = 'E';
            
            gradeElement.textContent = grade;
            
            // Remove all grade classes and add the appropriate one
            gradeElement.classList.remove('grade-a', 'grade-b', 'grade-c', 'grade-d', 'grade-e', 'grade-f');
            gradeElement.classList.add(`grade-${grade.toLowerCase()}`);
        }
    }

    for (let i = 0; i < caTest1Inputs.length; i++) {
        caTest1Inputs[i].addEventListener('input', function() {
            updateTotal(i);
        });

        caTest2Inputs[i].addEventListener('input', function() {
            updateTotal(i);
        });

        examInputs[i].addEventListener('input', function() {
            updateTotal(i);
        });

        // Initialize totals
        updateTotal(i);
    }

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('.delete-btn');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // Attendance calculation
    const daysSchoolOpen = document.getElementById('days_school_open');
    const daysPresent = document.getElementById('days_present');
    const daysAbsent = document.getElementById('days_absent');

    if (daysSchoolOpen && daysPresent && daysAbsent) {
        function updateDaysAbsent() {
            const open = parseInt(daysSchoolOpen.value) || 0;
            const present = parseInt(daysPresent.value) || 0;
            const absent = Math.max(0, open - present);
            daysAbsent.textContent = absent;
        }

        daysSchoolOpen.addEventListener('input', updateDaysAbsent);
        daysPresent.addEventListener('input', updateDaysAbsent);
        
        // Initialize on page load
        updateDaysAbsent();
    }

    // Print Report Card
    const printButton = document.getElementById('print-report');
    if (printButton) {
        printButton.addEventListener('click', function() {
            window.print();
        });
    }
});
