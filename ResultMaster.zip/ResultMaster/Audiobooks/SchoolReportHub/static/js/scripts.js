// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // Enable all tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Enable all popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Score form validation
    const scoreInputs = document.querySelectorAll('input[type="number"]');
    if (scoreInputs) {
        scoreInputs.forEach(function(input) {
            input.addEventListener('input', function() {
                validateScoreInput(this);
            });
            
            // Initial validation
            validateScoreInput(input);
        });
    }
    
    // CA and Exam score validation
    function validateScoreInput(input) {
        const value = parseInt(input.value);
        const max = parseInt(input.getAttribute('max'));
        
        if (isNaN(value)) {
            input.value = 0;
            return;
        }
        
        if (value < 0) {
            input.value = 0;
        } else if (value > max) {
            input.value = max;
        }
        
        // Calculate total if this is part of a score row
        if (input.classList.contains('score-input')) {
            const row = input.closest('tr');
            if (row) {
                const ca1Input = row.querySelector('.ca1-input');
                const ca2Input = row.querySelector('.ca2-input');
                const examInput = row.querySelector('.exam-input');
                const totalSpan = row.querySelector('.total-score');
                
                if (ca1Input && ca2Input && examInput && totalSpan) {
                    const ca1 = parseInt(ca1Input.value) || 0;
                    const ca2 = parseInt(ca2Input.value) || 0;
                    const exam = parseInt(examInput.value) || 0;
                    const total = ca1 + ca2 + exam;
                    
                    totalSpan.textContent = total;
                    
                    // Set grade based on total
                    const gradeSpan = row.querySelector('.grade');
                    if (gradeSpan) {
                        let grade = '';
                        if (total >= 80) grade = 'A+';
                        else if (total >= 70) grade = 'A';
                        else if (total >= 60) grade = 'B';
                        else if (total >= 50) grade = 'C';
                        else if (total >= 40) grade = 'D';
                        else grade = 'F';
                        
                        gradeSpan.textContent = grade;
                        
                        // Set cell class based on grade
                        if (grade === 'F') {
                            gradeSpan.className = 'grade badge bg-danger';
                        } else {
                            gradeSpan.className = 'grade badge bg-success';
                        }
                    }
                }
            }
        }
    }
    
    // Filter form auto-submit
    const filterForm = document.getElementById('filter-form');
    if (filterForm) {
        const filterSelects = filterForm.querySelectorAll('select');
        filterSelects.forEach(function(select) {
            select.addEventListener('change', function() {
                filterForm.submit();
            });
        });
    }
    
    // Attendance calculation
    const daysOpenedInput = document.querySelector('.days-school-opened');
    const daysPresentInputs = document.querySelectorAll('.days-present');
    const daysAbsentInputs = document.querySelectorAll('.days-absent');
    
    if (daysOpenedInput && daysPresentInputs.length > 0 && daysAbsentInputs.length > 0) {
        daysOpenedInput.addEventListener('input', function() {
            updateAttendance();
        });
        
        daysPresentInputs.forEach(function(input) {
            input.addEventListener('input', function() {
                const row = this.closest('tr');
                const absentInput = row.querySelector('.days-absent');
                const openedInput = daysOpenedInput;
                
                if (absentInput && openedInput) {
                    const opened = parseInt(openedInput.value) || 0;
                    const present = parseInt(this.value) || 0;
                    
                    if (present > opened) {
                        this.value = opened;
                    }
                    
                    absentInput.value = opened - present;
                }
            });
        });
        
        daysAbsentInputs.forEach(function(input) {
            input.addEventListener('input', function() {
                const row = this.closest('tr');
                const presentInput = row.querySelector('.days-present');
                const openedInput = daysOpenedInput;
                
                if (presentInput && openedInput) {
                    const opened = parseInt(openedInput.value) || 0;
                    const absent = parseInt(this.value) || 0;
                    
                    if (absent > opened) {
                        this.value = opened;
                    }
                    
                    presentInput.value = opened - absent;
                }
            });
        });
    }
    
    function updateAttendance() {
        const opened = parseInt(daysOpenedInput.value) || 0;
        
        daysPresentInputs.forEach(function(input) {
            const present = parseInt(input.value) || 0;
            const row = input.closest('tr');
            const absentInput = row.querySelector('.days-absent');
            
            if (present > opened) {
                input.value = opened;
            }
            
            if (absentInput) {
                absentInput.value = opened - parseInt(input.value);
            }
        });
    }
    
    // Print report button
    const printButton = document.getElementById('print-report');
    if (printButton) {
        printButton.addEventListener('click', function(e) {
            e.preventDefault();
            window.print();
        });
    }
});
