from app import app
import auth
import admin
import teacher
import parent
import lesson_notes
import os

if __name__ == "__main__":
    if not os.path.exists("data"):
        os.makedirs("data")
        
    # Create initial data files if they don't exist
    data_files = [
        "users.json", "students.json", "classes.json", 
        "subjects.json", "scores.json", "psychomotor.json", 
        "attendance.json"
    ]
    
    for file in data_files:
        file_path = f"data/{file}"
        if not os.path.exists(file_path):
            with open(file_path, "w") as f:
                f.write("[]")
    
    app.run(host="0.0.0.0", port=5000, debug=True)
