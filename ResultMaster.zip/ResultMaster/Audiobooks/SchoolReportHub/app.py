import os
from flask import Flask, redirect, url_for
from flask_login import LoginManager
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Configure login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# Import lesson_notes blueprint and register it
from lesson_notes import lesson_notes_bp
app.register_blueprint(lesson_notes_bp)

# Other blueprints (auth, admin, teacher, parent) are registered in their respective files

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.get_by_id(user_id)

@app.route('/')
def index():
    return redirect(url_for('login'))
