from flask import Blueprint, render_template, redirect, url_for, flash, request, make_response
from flask_login import login_required, current_user
import datetime
from models import User, Student, Class, Subject, Score, Psychomotor, Attendance
from app import app
from pdf_generator import generate_pdf

# Create blueprint
parent_bp = Blueprint('parent', __name__, url_prefix='/parent')

# Helper functions
def get_parent_children(parent_id):
    """Get children of a parent"""
    students = Student.get_all_students()
    return [student for student in students if student.get('parent_id') == parent_id]

def get_student_class(class_id):
    """Get class details for a student"""
    return Class.get_by_id(class_id)

def get_student_subjects(class_id):
    """Get subjects for a class"""
    subjects = Subject.get_all_subjects()
    return [subject for subject in subjects if subject.get('class_id') == class_id]

def get_subject_name(subject_id):
    """Get subject name"""
    subject = Subject.get_by_id(subject_id)
    return subject.name if subject else "Unknown Subject"

def get_student_total_scores(student_id, term, academic_session):
    """Calculate total scores for a student in all subjects"""
    scores = Score.get_student_scores(student_id, term, academic_session)
    
    total_ca1 = sum(int(score.ca_test1) for score in scores)
    total_ca2 = sum(int(score.ca_test2) for score in scores)
    total_exam = sum(int(score.exam) for score in scores)
    total_score = total_ca1 + total_ca2 + total_exam
    
    # Calculate subject total and average
    subject_count = len(scores)
    average = round(total_score / subject_count, 2) if subject_count > 0 else 0
    
    return {
        'total_ca1': total_ca1,
        'total_ca2': total_ca2,
        'total_exam': total_exam,
        'total_score': total_score,
        'subject_count': subject_count,
        'average': average
    }

# Routes
@parent_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'parent':
        flash('Access denied: Parent privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get parent's children
    children = get_parent_children(current_user.id)
    
    # Get class details for each child
    classes = Class.get_all_classes()
    class_names = {cls.get('id'): cls.get('name') for cls in classes}
    
    return render_template('parent/dashboard.html',
                         children=children,
                         class_names=class_names,
                         now=datetime.datetime.now())

@parent_bp.route('/view-result')
@login_required
def view_result():
    if current_user.role != 'parent':
        flash('Access denied: Parent privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get parameters
    student_id = request.args.get('student_id', '')
    term = request.args.get('term', '1st')
    academic_session = request.args.get('academic_session', '2023/2024')
    
    # Validate student belongs to this parent
    student = Student.get_by_id(student_id)
    if not student or student.parent_id != current_user.id:
        flash('Invalid student selected.', 'danger')
        return redirect(url_for('parent.dashboard'))
    
    # Get student class
    student_class = Class.get_by_id(student.class_id)
    class_name = student_class.name if student_class else "Unknown Class"
    
    # Get scores
    scores = Score.get_student_scores(student_id, term, academic_session)
    
    # Get subjects and create a dictionary with subject details
    subjects = Subject.get_all_subjects()
    subject_names = {subject.get('id'): subject.get('name') for subject in subjects}
    
    # Build result data
    result_data = []
    for score in scores:
        subject_name = subject_names.get(score.subject_id, "Unknown Subject")
        total = int(score.ca_test1) + int(score.ca_test2) + int(score.exam)
        
        result_data.append({
            'subject': subject_name,
            'ca_test1': score.ca_test1,
            'ca_test2': score.ca_test2,
            'exam': score.exam,
            'total': total,
            'grade': score.grade,
            'position': score.position
        })
    
    # Get psychomotor data
    psychomotor = Psychomotor.get_student_psychomotor(student_id, term, academic_session)
    
    # Get attendance data
    attendance = Attendance.get_student_attendance(student_id, term, academic_session)
    
    # Get totals
    totals = get_student_total_scores(student_id, term, academic_session)
    
    return render_template('parent/view_result.html',
                         student=student,
                         class_name=class_name,
                         term=term,
                         academic_session=academic_session,
                         results=result_data,
                         psychomotor=psychomotor,
                         attendance=attendance,
                         totals=totals,
                         now=datetime.datetime.now())

@parent_bp.route('/download-result')
@login_required
def download_result():
    if current_user.role != 'parent':
        flash('Access denied: Parent privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get parameters
    student_id = request.args.get('student_id', '')
    term = request.args.get('term', '1st')
    academic_session = request.args.get('academic_session', '2023/2024')
    
    # Validate student belongs to this parent
    student = Student.get_by_id(student_id)
    if not student or student.parent_id != current_user.id:
        flash('Invalid student selected.', 'danger')
        return redirect(url_for('parent.dashboard'))
    
    # Generate PDF
    pdf_bytes = generate_pdf(student_id, term, academic_session)
    
    # Create response
    response = make_response(pdf_bytes)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename={student.name}_{term}_{academic_session}_report.pdf'
    
    return response
    
# Register blueprint with Flask app
app.register_blueprint(parent_bp)
