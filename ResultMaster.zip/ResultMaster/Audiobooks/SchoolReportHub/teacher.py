from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField, IntegerField, TextAreaField
from wtforms.validators import DataRequired, NumberRange, Optional
from flask_login import login_required, current_user
import datetime
from models import User, Student, Class, Subject, Score, Psychomotor, Attendance
from app import app

# Create blueprint
teacher_bp = Blueprint('teacher', __name__, url_prefix='/teacher')

# Forms
class ScoreForm(FlaskForm):
    ca_test1 = IntegerField('CA Test 1', validators=[NumberRange(min=0, max=20)])
    ca_test2 = IntegerField('CA Test 2', validators=[NumberRange(min=0, max=20)])
    exam = IntegerField('Exam', validators=[NumberRange(min=0, max=60)])
    term = SelectField('Term', choices=[('1st', '1st Term'), ('2nd', '2nd Term'), ('3rd', '3rd Term')])
    academic_session = StringField('Academic Session', validators=[DataRequired()])
    submit = SubmitField('Submit')

class PsychomotorForm(FlaskForm):
    club_society = SelectField('Club/Society', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    drawing_painting = SelectField('Drawing/Painting', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    handwriting = SelectField('Handwriting', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    verbal_fluency = SelectField('Verbal Fluency', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    games_sports = SelectField('Games/Sports', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    computer = SelectField('Computer', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    
    # Affective traits
    punctuality = SelectField('Punctuality', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    attendance = SelectField('Attendance', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    reliability = SelectField('Reliability', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    honesty = SelectField('Honesty', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    relationship_others = SelectField('Relationship With Others', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    participation = SelectField('Participation', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    carrying_assignment = SelectField('Carrying Out Assignments', choices=[
        ('5', 'Excellent'), ('4', 'Very Good'), ('3', 'Good'), ('2', 'Fair'), ('1', 'Weak')
    ])
    
    # Attendance records
    days_school_open = IntegerField('Days School Open', validators=[DataRequired(), NumberRange(min=0)])
    days_present = IntegerField('Days Present', validators=[DataRequired(), NumberRange(min=0)])
    
    # Comments
    teacher_comment = TextAreaField('Teacher\'s Comment', validators=[DataRequired()])
    head_teacher_comment = TextAreaField('Head Teacher\'s Comment', validators=[Optional()])
    
    term = SelectField('Term', choices=[('1st', '1st Term'), ('2nd', '2nd Term'), ('3rd', '3rd Term')])
    academic_session = StringField('Academic Session', validators=[DataRequired()])
    
    submit = SubmitField('Submit')

# Helper functions
def get_teacher_classes(teacher_id):
    """Get classes assigned to a teacher"""
    classes = Class.get_all_classes()
    return [cls for cls in classes if cls.get('teacher_id') == teacher_id]

def get_teacher_subjects(teacher_id):
    """Get subjects assigned to a teacher"""
    subjects = Subject.get_all_subjects()
    return [subj for subj in subjects if subj.get('teacher_id') == teacher_id]

def get_students_by_class(class_id):
    """Get students in a class"""
    students = Student.get_all_students()
    return [student for student in students if student.get('class_id') == class_id]

def calculate_grade(total_score):
    """Calculate grade based on total score"""
    if total_score >= 70:
        return 'A'
    elif total_score >= 60:
        return 'B'
    elif total_score >= 50:
        return 'C'
    elif total_score >= 45:
        return 'D'
    elif total_score >= 40:
        return 'E'
    else:
        return 'F'

def calculate_positions(scores, subject_id, class_id, term, academic_session):
    """Calculate subject positions for a class"""
    # Get all students in the class
    class_students = get_students_by_class(class_id)
    student_ids = [student.get('id') for student in class_students]
    
    # Get all scores for this subject, class, term and academic session
    subject_scores = []
    for student_id in student_ids:
        for score in scores:
            if (score.get('student_id') == student_id and 
                score.get('subject_id') == subject_id and
                score.get('term') == term and
                score.get('academic_session') == academic_session):
                
                total = int(score.get('ca_test1', 0)) + int(score.get('ca_test2', 0)) + int(score.get('exam', 0))
                subject_scores.append({
                    'id': score.get('id'),
                    'student_id': student_id,
                    'total': total
                })
                break
    
    # Sort by total score (descending)
    subject_scores.sort(key=lambda x: x['total'], reverse=True)
    
    # Assign positions
    positions = {}
    for i, score in enumerate(subject_scores):
        positions[score['id']] = i + 1
    
    return positions

# Routes
@teacher_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'teacher':
        flash('Access denied: Teacher privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get classes and subjects assigned to this teacher
    teacher_classes = get_teacher_classes(current_user.id)
    teacher_subjects = get_teacher_subjects(current_user.id)
    
    # Get class and subject details
    classes = Class.get_all_classes()
    subjects = Subject.get_all_subjects()
    
    # Get class and subject names for display
    class_names = {cls.get('id'): cls.get('name') for cls in classes}
    subject_names = {subject.get('id'): subject.get('name') for subject in subjects}
    
    return render_template('teacher/dashboard.html',
                         teacher_classes=teacher_classes,
                         teacher_subjects=teacher_subjects,
                         class_names=class_names,
                         subject_names=subject_names,
                         now=datetime.datetime.now())

@teacher_bp.route('/enter-scores', methods=['GET', 'POST'])
@login_required
def enter_scores():
    if current_user.role != 'teacher':
        flash('Access denied: Teacher privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get subjects assigned to this teacher
    teacher_subjects = get_teacher_subjects(current_user.id)
    
    if not teacher_subjects:
        flash('You have no subjects assigned to you.', 'warning')
        return redirect(url_for('teacher.dashboard'))
    
    # Get class and subject details
    classes = Class.get_all_classes()
    subjects = Subject.get_all_subjects()
    
    # Get class and subject names for display
    class_names = {cls.get('id'): cls.get('name') for cls in classes}
    subject_names = {subject.get('id'): subject.get('name') for subject in subjects}
    
    # Get all students
    all_students = Student.get_all_students()
    
    # Group teacher's subjects by class
    subjects_by_class = {}
    for subject in teacher_subjects:
        class_id = subject.get('class_id')
        if class_id not in subjects_by_class:
            subjects_by_class[class_id] = []
        subjects_by_class[class_id].append(subject)
    
    # Get selected class and subject from query parameters
    selected_class = request.args.get('class_id', '')
    selected_subject = request.args.get('subject_id', '')
    selected_term = request.args.get('term', '1st')
    selected_session = request.args.get('academic_session', '2023/2024')
    
    # Get students for the selected class
    class_students = []
    if selected_class:
        class_students = [student for student in all_students if student.get('class_id') == selected_class]
    
    # Get scores for the selected subject, class, term, and session
    scores = []
    if selected_class and selected_subject:
        all_scores = Score.get_all_scores()
        for student in class_students:
            student_score = None
            for score in all_scores:
                if (score.get('student_id') == student.get('id') and 
                    score.get('subject_id') == selected_subject and
                    score.get('term') == selected_term and
                    score.get('academic_session') == selected_session):
                    student_score = score
                    break
            
            scores.append({
                'student_id': student.get('id'),
                'student_name': student.get('name'),
                'ca_test1': student_score.get('ca_test1', 0) if student_score else 0,
                'ca_test2': student_score.get('ca_test2', 0) if student_score else 0,
                'exam': student_score.get('exam', 0) if student_score else 0,
                'score_id': student_score.get('id') if student_score else None
            })
    
    form = ScoreForm()
    
    if form.validate_on_submit():
        student_id = request.form.get('student_id')
        score_id = request.form.get('score_id')
        
        # Validate that the student exists
        student = Student.get_by_id(student_id)
        if not student:
            flash('Student not found.', 'danger')
            return redirect(url_for('teacher.enter_scores', 
                                   class_id=selected_class, 
                                   subject_id=selected_subject,
                                   term=selected_term,
                                   academic_session=selected_session))
        
        # Calculate total and grade
        total = form.ca_test1.data + form.ca_test2.data + form.exam.data
        grade = calculate_grade(total)
        
        if score_id:
            # Update existing score
            score = Score(
                id=score_id,
                student_id=student_id,
                subject_id=selected_subject,
                ca_test1=form.ca_test1.data,
                ca_test2=form.ca_test2.data,
                exam=form.exam.data,
                term=form.term.data,
                academic_session=form.academic_session.data,
                grade=grade
            )
        else:
            # Create new score
            score = Score(
                student_id=student_id,
                subject_id=selected_subject,
                ca_test1=form.ca_test1.data,
                ca_test2=form.ca_test2.data,
                exam=form.exam.data,
                term=form.term.data,
                academic_session=form.academic_session.data,
                grade=grade
            )
        
        score.save()
        
        # Calculate and update positions
        all_scores = Score.get_all_scores()
        positions = calculate_positions(all_scores, selected_subject, selected_class, form.term.data, form.academic_session.data)
        
        # Update the position for this score
        if score.id in positions:
            score.position = positions[score.id]
            score.save()
        
        flash('Score saved successfully.', 'success')
        return redirect(url_for('teacher.enter_scores', 
                               class_id=selected_class, 
                               subject_id=selected_subject,
                               term=form.term.data,
                               academic_session=form.academic_session.data))
    
    form.term.data = selected_term
    form.academic_session.data = selected_session
    
    return render_template('teacher/enter_scores.html',
                         form=form,
                         subjects_by_class=subjects_by_class,
                         class_names=class_names,
                         subject_names=subject_names,
                         selected_class=selected_class,
                         selected_subject=selected_subject,
                         selected_term=selected_term,
                         selected_session=selected_session,
                         students=scores,
                         now=datetime.datetime.now())

@teacher_bp.route('/manage-psychomotor', methods=['GET', 'POST'])
@login_required
def manage_psychomotor():
    if current_user.role != 'teacher':
        flash('Access denied: Teacher privileges required.', 'danger')
        return redirect(url_for('login'))
    
    # Get classes assigned to this teacher
    teacher_classes = get_teacher_classes(current_user.id)
    
    if not teacher_classes:
        flash('You have no classes assigned to you.', 'warning')
        return redirect(url_for('teacher.dashboard'))
    
    # Get class details
    classes = Class.get_all_classes()
    
    # Get class names for display
    class_names = {cls.get('id'): cls.get('name') for cls in classes}
    
    # Get all students
    all_students = Student.get_all_students()
    
    # Get selected class from query parameters
    selected_class = request.args.get('class_id', '')
    selected_term = request.args.get('term', '1st')
    selected_session = request.args.get('academic_session', '2023/2024')
    selected_student = request.args.get('student_id', '')
    
    # Get students for the selected class
    class_students = []
    if selected_class:
        class_students = [student for student in all_students if student.get('class_id') == selected_class]
    
    # Get the selected student's psychomotor data
    psychomotor_data = None
    attendance_data = None
    if selected_student:
        psychomotor_data = Psychomotor.get_student_psychomotor(selected_student, selected_term, selected_session)
        attendance_data = Attendance.get_student_attendance(selected_student, selected_term, selected_session)
    
    form = PsychomotorForm()
    
    if form.validate_on_submit():
        # Calculate days absent
        days_absent = form.days_school_open.data - form.days_present.data
        if days_absent < 0:
            flash('Days present cannot be greater than days school open.', 'danger')
            return redirect(url_for('teacher.manage_psychomotor', 
                                   class_id=selected_class,
                                   term=selected_term,
                                   academic_session=selected_session,
                                   student_id=selected_student))
        
        # Save attendance data
        attendance = Attendance(
            student_id=selected_student,
            term=form.term.data,
            academic_session=form.academic_session.data,
            days_school_open=form.days_school_open.data,
            days_present=form.days_present.data,
            days_absent=days_absent
        )
        attendance.save()
        
        # Save psychomotor data
        psychomotor = Psychomotor(
            student_id=selected_student,
            term=form.term.data,
            academic_session=form.academic_session.data,
            club_society=form.club_society.data,
            drawing_painting=form.drawing_painting.data,
            handwriting=form.handwriting.data,
            verbal_fluency=form.verbal_fluency.data,
            games_sports=form.games_sports.data,
            computer=form.computer.data,
            punctuality=form.punctuality.data,
            attendance=form.attendance.data,
            reliability=form.reliability.data,
            honesty=form.honesty.data,
            relationship_others=form.relationship_others.data,
            participation=form.participation.data,
            carrying_assignment=form.carrying_assignment.data,
            class_attendance=attendance.id,
            teacher_comment=form.teacher_comment.data,
            head_teacher_comment=form.head_teacher_comment.data
        )
        psychomotor.save()
        
        flash('Psychomotor data saved successfully.', 'success')
        return redirect(url_for('teacher.manage_psychomotor', 
                               class_id=selected_class,
                               term=form.term.data,
                               academic_session=form.academic_session.data,
                               student_id=selected_student))
    
    # Pre-populate the form with existing data
    if psychomotor_data and attendance_data:
        form.club_society.data = psychomotor_data.club_society
        form.drawing_painting.data = psychomotor_data.drawing_painting
        form.handwriting.data = psychomotor_data.handwriting
        form.verbal_fluency.data = psychomotor_data.verbal_fluency
        form.games_sports.data = psychomotor_data.games_sports
        form.computer.data = psychomotor_data.computer
        form.punctuality.data = psychomotor_data.punctuality
        form.attendance.data = psychomotor_data.attendance
        form.reliability.data = psychomotor_data.reliability
        form.honesty.data = psychomotor_data.honesty
        form.relationship_others.data = psychomotor_data.relationship_others
        form.participation.data = psychomotor_data.participation
        form.carrying_assignment.data = psychomotor_data.carrying_assignment
        form.days_school_open.data = attendance_data.days_school_open
        form.days_present.data = attendance_data.days_present
        form.teacher_comment.data = psychomotor_data.teacher_comment
        form.head_teacher_comment.data = psychomotor_data.head_teacher_comment
    
    form.term.data = selected_term
    form.academic_session.data = selected_session
    
    return render_template('teacher/manage_psychomotor.html',
                         form=form,
                         teacher_classes=teacher_classes,
                         class_names=class_names,
                         selected_class=selected_class,
                         selected_term=selected_term,
                         selected_session=selected_session,
                         selected_student=selected_student,
                         students=class_students,
                         now=datetime.datetime.now())

# Register blueprint with Flask app
app.register_blueprint(teacher_bp)
