import os
import json
import uuid
import logging
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Define data file paths
DATA_DIR = 'data'
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
STUDENTS_FILE = os.path.join(DATA_DIR, 'students.json')
CLASSES_FILE = os.path.join(DATA_DIR, 'classes.json')
SUBJECTS_FILE = os.path.join(DATA_DIR, 'subjects.json')
SCORES_FILE = os.path.join(DATA_DIR, 'scores.json')
PSYCHOMOTOR_FILE = os.path.join(DATA_DIR, 'psychomotor.json')
ATTENDANCE_FILE = os.path.join(DATA_DIR, 'attendance.json')

def init_data_files():
    """Initialize data files if they don't exist"""
    # Create data directory if it doesn't exist
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    
    # Initialize users file with default admin account
    if not os.path.exists(USERS_FILE):
        default_users = [
            {
                'id': str(uuid.uuid4()),
                'username': 'admin',
                'password': generate_password_hash('admin123'),
                'name': 'System Administrator',
                'role': 'admin'
            },
            {
                'id': str(uuid.uuid4()),
                'username': 'teacher1',
                'password': generate_password_hash('teacher123'),
                'name': 'John Smith',
                'role': 'teacher',
                'subject_ids': [],
                'class_ids': []
            },
            {
                'id': str(uuid.uuid4()),
                'username': 'parent1',
                'password': generate_password_hash('parent123'),
                'name': 'Parent One',
                'role': 'parent'
            }
        ]
        save_to_file(USERS_FILE, default_users)
    
    # Initialize other files with empty arrays
    for file_path in [STUDENTS_FILE, CLASSES_FILE, SUBJECTS_FILE, SCORES_FILE, PSYCHOMOTOR_FILE, ATTENDANCE_FILE]:
        if not os.path.exists(file_path):
            save_to_file(file_path, [])

def save_to_file(file_path, data):
    """Save data to a JSON file"""
    try:
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=4)
        return True
    except Exception as e:
        logger.error(f"Error saving to {file_path}: {str(e)}")
        return False

def load_from_file(file_path):
    """Load data from a JSON file"""
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                return json.load(f)
        return []
    except Exception as e:
        logger.error(f"Error loading from {file_path}: {str(e)}")
        return []

# User functions
def get_user():
    """Get all users"""
    return load_from_file(USERS_FILE)

def get_user_by_id(user_id):
    """Get user by ID"""
    users = get_user()
    return next((user for user in users if user['id'] == user_id), None)

def get_user_by_username(username):
    """Get user by username"""
    users = get_user()
    return next((user for user in users if user['username'] == username), None)

def authenticate_user(username, password):
    """Authenticate user with username and password"""
    user = get_user_by_username(username)
    if user and check_password_hash(user['password'], password):
        return user
    return None

# Class functions
def get_classes():
    """Get all classes"""
    return load_from_file(CLASSES_FILE)

def get_class_by_id(class_id):
    """Get class by ID"""
    classes = get_classes()
    return next((c for c in classes if c['id'] == class_id), None)

def add_class(class_data):
    """Add a new class"""
    classes = get_classes()
    class_data['id'] = str(uuid.uuid4())
    classes.append(class_data)
    return save_to_file(CLASSES_FILE, classes)

def update_class(class_id, class_data):
    """Update an existing class"""
    classes = get_classes()
    for i, c in enumerate(classes):
        if c['id'] == class_id:
            classes[i].update(class_data)
            classes[i]['id'] = class_id  # Ensure ID doesn't change
            return save_to_file(CLASSES_FILE, classes)
    return False

def delete_class(class_id):
    """Delete a class"""
    classes = get_classes()
    classes = [c for c in classes if c['id'] != class_id]
    return save_to_file(CLASSES_FILE, classes)

# Subject functions
def get_subjects():
    """Get all subjects"""
    return load_from_file(SUBJECTS_FILE)

def get_subject_by_id(subject_id):
    """Get subject by ID"""
    subjects = get_subjects()
    return next((s for s in subjects if s['id'] == subject_id), None)

def add_subject(subject_data):
    """Add a new subject"""
    subjects = get_subjects()
    subject_data['id'] = str(uuid.uuid4())
    subjects.append(subject_data)
    return save_to_file(SUBJECTS_FILE, subjects)

def update_subject(subject_id, subject_data):
    """Update an existing subject"""
    subjects = get_subjects()
    for i, s in enumerate(subjects):
        if s['id'] == subject_id:
            subjects[i].update(subject_data)
            subjects[i]['id'] = subject_id  # Ensure ID doesn't change
            return save_to_file(SUBJECTS_FILE, subjects)
    return False

def delete_subject(subject_id):
    """Delete a subject"""
    subjects = get_subjects()
    subjects = [s for s in subjects if s['id'] != subject_id]
    return save_to_file(SUBJECTS_FILE, subjects)

# Student functions
def get_students():
    """Get all students"""
    return load_from_file(STUDENTS_FILE)

def get_student_by_id(student_id):
    """Get student by ID"""
    students = get_students()
    return next((s for s in students if s['id'] == student_id), None)

def get_students_by_class(class_id):
    """Get students by class ID"""
    students = get_students()
    return [s for s in students if s['class_id'] == class_id]

def add_student(student_data):
    """Add a new student"""
    students = get_students()
    student_data['id'] = str(uuid.uuid4())
    students.append(student_data)
    return save_to_file(STUDENTS_FILE, students)

def update_student(student_id, student_data):
    """Update an existing student"""
    students = get_students()
    for i, s in enumerate(students):
        if s['id'] == student_id:
            students[i].update(student_data)
            students[i]['id'] = student_id  # Ensure ID doesn't change
            return save_to_file(STUDENTS_FILE, students)
    return False

def delete_student(student_id):
    """Delete a student"""
    students = get_students()
    students = [s for s in students if s['id'] != student_id]
    return save_to_file(STUDENTS_FILE, students)

# Teacher functions
def add_teacher(teacher_data):
    """Add a new teacher"""
    users = get_user()
    
    # Create teacher user
    teacher = {
        'id': str(uuid.uuid4()),
        'username': teacher_data['username'],
        'password': generate_password_hash(teacher_data['password']),
        'name': teacher_data['name'],
        'role': 'teacher',
        'subject_ids': teacher_data['subject_ids'],
        'class_ids': teacher_data['class_ids']
    }
    
    users.append(teacher)
    return save_to_file(USERS_FILE, users)

def update_teacher(teacher_id, teacher_data):
    """Update an existing teacher"""
    users = get_user()
    
    for i, user in enumerate(users):
        if user['id'] == teacher_id and user['role'] == 'teacher':
            # Update fields
            users[i]['username'] = teacher_data['username']
            users[i]['name'] = teacher_data['name']
            users[i]['subject_ids'] = teacher_data['subject_ids']
            users[i]['class_ids'] = teacher_data['class_ids']
            
            # Update password if provided
            if 'password' in teacher_data and teacher_data['password']:
                users[i]['password'] = generate_password_hash(teacher_data['password'])
            
            return save_to_file(USERS_FILE, users)
    
    return False

def delete_teacher(teacher_id):
    """Delete a teacher"""
    users = get_user()
    users = [u for u in users if u['id'] != teacher_id or u['role'] != 'teacher']
    return save_to_file(USERS_FILE, users)

def get_teacher_classes(teacher_id):
    """Get classes assigned to a teacher"""
    teacher = get_user_by_id(teacher_id)
    if not teacher or teacher['role'] != 'teacher':
        return []
    
    classes = get_classes()
    return [c for c in classes if c['id'] in teacher.get('class_ids', [])]

def get_teacher_subjects(teacher_id):
    """Get subjects assigned to a teacher"""
    teacher = get_user_by_id(teacher_id)
    if not teacher or teacher['role'] != 'teacher':
        return []
    
    subjects = get_subjects()
    return [s for s in subjects if s['id'] in teacher.get('subject_ids', [])]

# Parent functions
def get_children_by_parent(parent_id):
    """Get children for a parent"""
    students = get_students()
    return [s for s in students if s.get('parent_id') == parent_id]

# Score functions
def get_scores():
    """Get all scores"""
    return load_from_file(SCORES_FILE)

def get_scores_by_student(student_id, term, session_year):
    """Get scores for a student in a specific term and session"""
    scores = get_scores()
    return [s for s in scores if s['student_id'] == student_id and s['term'] == term and s['session'] == session_year]

def get_scores_by_class(class_id, subject_id, term, session_year):
    """Get scores for a class in a specific subject, term, and session"""
    scores = get_scores()
    class_scores = [s for s in scores if s['class_id'] == class_id and 
                   s['subject_id'] == subject_id and 
                   s['term'] == term and 
                   s['session'] == session_year]
    
    # Convert to dictionary for easier access
    scores_dict = {}
    for score in class_scores:
        scores_dict[score['student_id']] = score
    
    return scores_dict

def update_scores(scores_data):
    """Update scores"""
    all_scores = get_scores()
    
    for new_score in scores_data:
        # Check if score exists
        score_exists = False
        for i, score in enumerate(all_scores):
            if (score['student_id'] == new_score['student_id'] and
                score['subject_id'] == new_score['subject_id'] and
                score['term'] == new_score['term'] and
                score['session'] == new_score['session']):
                
                # Update existing score
                all_scores[i] = new_score
                score_exists = True
                break
        
        # Add new score if doesn't exist
        if not score_exists:
            all_scores.append(new_score)
    
    return save_to_file(SCORES_FILE, all_scores)

# Psychomotor functions
def get_psychomotor():
    """Get all psychomotor data"""
    return load_from_file(PSYCHOMOTOR_FILE)

def get_psychomotor_by_student(student_id, term, session_year):
    """Get psychomotor data for a student in a specific term and session"""
    psychomotor_data = get_psychomotor()
    return next((p for p in psychomotor_data if 
                p['student_id'] == student_id and 
                p['term'] == term and 
                p['session'] == session_year), None)

def update_psychomotor(psychomotor_data):
    """Update psychomotor data"""
    all_psychomotor = get_psychomotor()
    
    for new_data in psychomotor_data:
        # Check if data exists
        data_exists = False
        for i, data in enumerate(all_psychomotor):
            if (data['student_id'] == new_data['student_id'] and
                data['term'] == new_data['term'] and
                data['session'] == new_data['session']):
                
                # Update existing data
                all_psychomotor[i] = new_data
                data_exists = True
                break
        
        # Add new data if doesn't exist
        if not data_exists:
            all_psychomotor.append(new_data)
    
    return save_to_file(PSYCHOMOTOR_FILE, all_psychomotor)

# Attendance functions
def get_attendance():
    """Get all attendance data"""
    return load_from_file(ATTENDANCE_FILE)

def get_attendance_by_student(student_id, term, session_year):
    """Get attendance data for a student in a specific term and session"""
    attendance_data = get_attendance()
    return next((a for a in attendance_data if 
                a['student_id'] == student_id and 
                a['term'] == term and 
                a['session'] == session_year), None)

def update_attendance(attendance_data):
    """Update attendance data"""
    all_attendance = get_attendance()
    
    for new_data in attendance_data:
        # Check if data exists
        data_exists = False
        for i, data in enumerate(all_attendance):
            if (data['student_id'] == new_data['student_id'] and
                data['term'] == new_data['term'] and
                data['session'] == new_data['session']):
                
                # Update existing data
                all_attendance[i] = new_data
                data_exists = True
                break
        
        # Add new data if doesn't exist
        if not data_exists:
            all_attendance.append(new_data)
    
    return save_to_file(ATTENDANCE_FILE, all_attendance)
