import os
import time
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, 
    Image, PageBreak
)
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from utils.data import (
    get_student_by_id, get_class_by_id, get_subject_by_id,
    get_scores_by_student, get_psychomotor_by_student, get_attendance_by_student
)

def generate_result_pdf(student_id, term, session):
    """Generate PDF report card for a student"""
    try:
        # Get student data
        student = get_student_by_id(student_id)
        if not student:
            return None
        
        # Get class data
        class_data = get_class_by_id(student['class_id'])
        if not class_data:
            return None
        
        # Get scores
        scores = get_scores_by_student(student_id, term, session)
        
        # Get psychomotor data
        psychomotor = get_psychomotor_by_student(student_id, term, session)
        
        # Get attendance data
        attendance = get_attendance_by_student(student_id, term, session)
        
        # Calculate totals and grades
        calculate_results(scores)
        
        # Generate PDF
        pdf_filename = f"report_card_{student_id}_{term}_{session.replace('/', '_')}.pdf"
        pdf_path = os.path.join('static', pdf_filename)
        
        # Create output directory if it doesn't exist
        os.makedirs('static', exist_ok=True)
        
        # Create the PDF document
        doc = SimpleDocTemplate(
            pdf_path,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        # Build the PDF content
        story = []
        
        # Add styles
        styles = getSampleStyleSheet()
        title_style = styles['Heading1']
        subtitle_style = styles['Heading2']
        normal_style = styles['Normal']
        
        # Header - School name and logo
        header_data = [
            [
                Paragraph("<b>ROSE & PHILIPS ROYAL ACADEMY</b>", title_style),
            ],
            [
                Paragraph("Motto: A Better Future Starts Here", subtitle_style),
            ],
            [
                Paragraph("25, Oshilaja Street, Oshingjje, Benin City,<br/>Edo State, Nigeria", normal_style),
            ],
            [
                Paragraph("Telephone(s): 08026671763, 09076745469<br/>Email Address: rosephilipsacademy@gmail.com", normal_style),
            ]
        ]
        
        header_table = Table(header_data, colWidths=[450])
        header_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        
        story.append(header_table)
        story.append(Spacer(1, 0.5*inch))
        
        # Title - Report Card
        story.append(Paragraph("<b>FIRST TERM PERFORMANCE REPORT SHEET</b>", title_style))
        story.append(Spacer(1, 0.25*inch))
        
        # Student Information
        student_info = [
            [
                Paragraph("<b>Pupil's Name:</b>", normal_style),
                Paragraph(student.get('name', ''), normal_style),
                Paragraph("<b>Class:</b>", normal_style),
                Paragraph(f"{class_data.get('name', '')} {class_data.get('section', '')}", normal_style)
            ],
            [
                Paragraph("<b>Class Population:</b>", normal_style),
                Paragraph(str(len(get_class_by_id(student['class_id']))), normal_style),
                Paragraph("<b>Gender:</b>", normal_style),
                Paragraph("Male" if student.get('gender') == 'M' else "Female", normal_style)
            ],
            [
                Paragraph("<b>No of Subjects on Offer:</b>", normal_style),
                Paragraph(str(len(scores)), normal_style),
                Paragraph("<b>Overall Grade:</b>", normal_style),
                Paragraph(calculate_overall_grade(scores), normal_style)
            ],
            [
                Paragraph("<b>Admission No:</b>", normal_style),
                Paragraph(student.get('admission_no', ''), normal_style),
                Paragraph("<b>Term:</b>", normal_style),
                Paragraph(term, normal_style)
            ],
            [
                Paragraph("<b>Academic Session:</b>", normal_style),
                Paragraph(session, normal_style),
                Paragraph("<b>Class Average Marks:</b>", normal_style),
                Paragraph(calculate_class_average(scores), normal_style)
            ]
        ]
        
        student_table = Table(student_info, colWidths=[110, 120, 100, 120])
        student_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('BACKGROUND', (2, 0), (2, -1), colors.lightgrey),
        ]))
        
        story.append(student_table)
        story.append(Spacer(1, 0.25*inch))
        
        # Result Table
        result_data = [
            [
                Paragraph("<b>Subjects</b>", normal_style),
                Paragraph("<b>CA Test 1</b>", normal_style),
                Paragraph("<b>CA Test 2</b>", normal_style),
                Paragraph("<b>Exam</b>", normal_style),
                Paragraph("<b>Total</b>", normal_style),
                Paragraph("<b>Subject Position</b>", normal_style),
                Paragraph("<b>Grade</b>", normal_style),
                Paragraph("<b>Remark</b>", normal_style),
            ]
        ]
        
        # Add subjects and scores
        for score in scores:
            subject = get_subject_by_id(score.get('subject_id', ''))
            subject_name = subject.get('name', '') if subject else 'Unknown Subject'
            
            result_data.append([
                Paragraph(subject_name, normal_style),
                Paragraph(str(score.get('ca1', 0)), normal_style),
                Paragraph(str(score.get('ca2', 0)), normal_style),
                Paragraph(str(score.get('exam', 0)), normal_style),
                Paragraph(str(score.get('total', 0)), normal_style),
                Paragraph(str(score.get('position', 0)), normal_style),
                Paragraph(score.get('grade', ''), normal_style),
                Paragraph(score.get('comment', ''), normal_style),
            ])
        
        # Add empty rows if needed
        while len(result_data) < 15:  # Add at least 14 subject rows
            result_data.append([
                Paragraph('', normal_style),
                Paragraph('', normal_style),
                Paragraph('', normal_style),
                Paragraph('', normal_style),
                Paragraph('', normal_style),
                Paragraph('', normal_style),
                Paragraph('', normal_style),
                Paragraph('', normal_style),
            ])
        
        result_table = Table(result_data, colWidths=[120, 40, 40, 40, 40, 50, 40, 80])
        result_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
        ]))
        
        story.append(result_table)
        story.append(Spacer(1, 0.25*inch))
        
        # Grade keys
        grade_key = [
            [
                Paragraph("<b>Grade Keys:</b>", normal_style),
                Paragraph("80-100 = A+", normal_style),
                Paragraph("70-79 = A", normal_style),
                Paragraph("60-69 = B", normal_style),
                Paragraph("50-59 = C", normal_style),
                Paragraph("40-49 = D", normal_style),
                Paragraph("<40 = F", normal_style),
            ]
        ]
        
        grade_table = Table(grade_key, colWidths=[90, 60, 60, 60, 60, 60, 60])
        grade_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BACKGROUND', (0, 0), (0, 0), colors.lightgrey),
        ]))
        
        story.append(grade_table)
        story.append(Spacer(1, 0.25*inch))
        
        # Attendance table
        attendance_data = [
            [
                Paragraph("<b>Attendance Table</b>", normal_style),
                Paragraph("", normal_style),
                Paragraph("<b>Session Averages</b>", normal_style),
                Paragraph("", normal_style),
            ],
            [
                Paragraph("<b>No of Times School Opened</b>", normal_style),
                Paragraph(attendance.get('days_school_opened', '0') if attendance else '0', normal_style),
                Paragraph("<b>1st Term</b>", normal_style),
                Paragraph(calculate_term_average(scores), normal_style),
            ],
            [
                Paragraph("<b>No of Times Present</b>", normal_style),
                Paragraph(attendance.get('days_present', '0') if attendance else '0', normal_style),
                Paragraph("<b>2nd Term</b>", normal_style),
                Paragraph("0.00", normal_style),
            ],
            [
                Paragraph("<b>No of Times Absent</b>", normal_style),
                Paragraph(attendance.get('days_absent', '0') if attendance else '0', normal_style),
                Paragraph("<b>3rd Term</b>", normal_style),
                Paragraph("0.00", normal_style),
            ],
            [
                Paragraph("", normal_style),
                Paragraph("", normal_style),
                Paragraph("<b>Cumulative Average</b>", normal_style),
                Paragraph("0.00", normal_style),
            ]
        ]
        
        attendance_table = Table(attendance_data, colWidths=[150, 70, 150, 80])
        attendance_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BACKGROUND', (0, 0), (1, 0), colors.lightgrey),
            ('BACKGROUND', (2, 0), (3, 0), colors.lightgrey),
            ('BACKGROUND', (0, 1), (0, 3), colors.lightgrey),
            ('BACKGROUND', (2, 1), (2, 4), colors.lightgrey),
            ('SPAN', (0, 0), (1, 0)),
            ('SPAN', (2, 0), (3, 0)),
        ]))
        
        story.append(attendance_table)
        story.append(Spacer(1, 0.25*inch))
        
        # Psychomotor and affective traits
        if psychomotor:
            psychomotor_data = [
                [
                    Paragraph("<b>Psychomotor</b>", normal_style),
                    Paragraph("<b>Rating</b>", normal_style),
                    Paragraph("<b>Affective Traits</b>", normal_style),
                    Paragraph("<b>Rating</b>", normal_style),
                ],
                [
                    Paragraph("Crafts/Society", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('crafts', '1')), normal_style),
                    Paragraph("Punctuality", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('punctuality', '1')), normal_style),
                ],
                [
                    Paragraph("Drawing/Painting", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('drawing_painting', '1')), normal_style),
                    Paragraph("Neatness", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('neatness', '1')), normal_style),
                ],
                [
                    Paragraph("Handwriting", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('handwriting', '1')), normal_style),
                    Paragraph("Attendance", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('attendance', '1')), normal_style),
                ],
                [
                    Paragraph("Verbal Fluency", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('verbal_fluency', '1')), normal_style),
                    Paragraph("Relationship With Others", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('relationship', '1')), normal_style),
                ],
                [
                    Paragraph("Computer", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('computer', '1')), normal_style),
                    Paragraph("Leadership", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('leadership', '1')), normal_style),
                ],
                [
                    Paragraph("Games/Sports", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('games_sports', '1')), normal_style),
                    Paragraph("Honesty", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('honesty', '1')), normal_style),
                ],
                [
                    Paragraph("", normal_style),
                    Paragraph("", normal_style),
                    Paragraph("Carrying Out Assignments", normal_style),
                    Paragraph(get_rating_text(psychomotor.get('participation', '1')), normal_style),
                ]
            ]
            
            psychomotor_table = Table(psychomotor_data, colWidths=[150, 70, 150, 80])
            psychomotor_table.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('BACKGROUND', (0, 0), (1, 0), colors.lightgrey),
                ('BACKGROUND', (2, 0), (3, 0), colors.lightgrey),
            ]))
            
            story.append(psychomotor_table)
            story.append(Spacer(1, 0.25*inch))
            
            # Domain Rating key
            domain_key = [
                [
                    Paragraph("<b>Domain Rating:</b>", normal_style),
                    Paragraph("5 = \"Excellent\"", normal_style),
                    Paragraph("4 = \"Very Good\"", normal_style),
                    Paragraph("3 = \"Good\"", normal_style),
                    Paragraph("2 = \"Fair\"", normal_style),
                    Paragraph("1 = \"Weak\"", normal_style),
                ]
            ]
            
            domain_table = Table(domain_key, colWidths=[90, 80, 80, 70, 60, 70])
            domain_table.setStyle(TableStyle([
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('BACKGROUND', (0, 0), (0, 0), colors.lightgrey),
            ]))
            
            story.append(domain_table)
            story.append(Spacer(1, 0.25*inch))
        
        # Comments
        comments_data = [
            [
                Paragraph("<b>Teacher's Comment</b>", normal_style),
                Paragraph(psychomotor.get('teacher_comment', '') if psychomotor else '', normal_style)
            ],
            [
                Paragraph("<b>Head-Teacher's Comment</b>", normal_style),
                Paragraph(psychomotor.get('head_teacher_comment', '') if psychomotor else '', normal_style)
            ],
            [
                Paragraph("<b>Next Term Begins</b>", normal_style),
                Paragraph("Monday, 18 September 2023", normal_style)
            ],
            [
                Paragraph("<b>Signature, Stamp and Date</b>", normal_style),
                Paragraph("", normal_style)
            ]
        ]
        
        comments_table = Table(comments_data, colWidths=[150, 300])
        comments_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ]))
        
        story.append(comments_table)
        
        # Footer
        footer_text = "Any alteration whatsoever on this document renders it invalid!"
        story.append(Spacer(1, 0.5*inch))
        story.append(Paragraph(footer_text, normal_style))
        
        # Build PDF
        doc.build(story)
        
        return pdf_path.replace('static/', '')
    
    except Exception as e:
        print(f"Error generating PDF: {str(e)}")
        return None

def calculate_results(scores):
    """Calculate total, grade, and remarks for each score"""
    for score in scores:
        # Calculate total
        ca1 = int(score.get('ca1', 0))
        ca2 = int(score.get('ca2', 0))
        exam = int(score.get('exam', 0))
        total = ca1 + ca2 + exam
        
        # Assign total
        score['total'] = total
        
        # Calculate grade
        if total >= 80:
            grade = 'A+'
        elif total >= 70:
            grade = 'A'
        elif total >= 60:
            grade = 'B'
        elif total >= 50:
            grade = 'C'
        elif total >= 40:
            grade = 'D'
        else:
            grade = 'F'
        
        # Assign grade
        score['grade'] = grade
        
        # Default position (in real application, this would be calculated based on class ranking)
        score['position'] = '1st'

def calculate_overall_grade(scores):
    """Calculate overall grade"""
    if not scores:
        return 'N/A'
    
    total_score = sum(score.get('total', 0) for score in scores)
    average = total_score / len(scores) if scores else 0
    
    if average >= 80:
        return 'A+'
    elif average >= 70:
        return 'A'
    elif average >= 60:
        return 'B'
    elif average >= 50:
        return 'C'
    elif average >= 40:
        return 'D'
    else:
        return 'F'

def calculate_class_average(scores):
    """Calculate class average"""
    if not scores:
        return '0.00'
    
    total_score = sum(score.get('total', 0) for score in scores)
    average = total_score / len(scores) if scores else 0
    
    return f"{average:.2f}"

def calculate_term_average(scores):
    """Calculate term average"""
    if not scores:
        return '0.00'
    
    total_score = sum(score.get('total', 0) for score in scores)
    average = total_score / len(scores) if scores else 0
    
    return f"{average:.2f}"

def get_rating_text(rating):
    """Convert numeric rating to text"""
    try:
        rating_value = int(rating)
        if rating_value == 5:
            return "Excellent"
        elif rating_value == 4:
            return "Very Good"
        elif rating_value == 3:
            return "Good"
        elif rating_value == 2:
            return "Fair"
        else:
            return "Weak"
    except (ValueError, TypeError):
        return "Weak"
