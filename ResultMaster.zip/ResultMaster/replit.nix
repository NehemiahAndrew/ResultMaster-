{pkgs}: {
  deps = [
    pkgs.cairo
    pkgs.glibcLocales
    pkgs.freetype
    pkgs.postgresql
    pkgs.openssl
  ];
}
