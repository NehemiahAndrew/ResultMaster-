import os
import secrets

# Database config
DATABASE = os.path.join(os.path.dirname(__file__), 'results.db')

# Flask config
SECRET_KEY = os.getenv('SECRET_KEY', secrets.token_hex(32))
DEBUG = False

# App config
APPLICATION_NAME = "Results Management System"
