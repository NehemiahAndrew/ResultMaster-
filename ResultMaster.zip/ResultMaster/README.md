# Result Management System

A comprehensive web application for managing student results, built with Python Flask and SQLite.

## Features

- **User Management**
  - Admin, Teacher, and Student roles with different permissions
  - Registration and authentication system
  - User profiles and role-based access control

- **Result Management**
  - Add, edit, and delete student results
  - View individual and aggregate result data
  - Grade calculation and term-wise result organization

- **Dashboard & Analytics**
  - Role-specific dashboards
  - Performance metrics and visualizations
  - Searchable and filterable result tables

## Setup and Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd result-management-system
   ```

2. Install dependencies:
   ```
   pip install flask
   ```

3. Run the application:
   ```
   python app.py
   ```

4. Access the application:
   Open your browser and go to `http://localhost:5000`

## Default Credentials

- **Admin Account**
  - Username: admin
  - Password: admin123

## Project Structure

- `app.py`: Main application file with routes
- `models.py`: Database models and setup
- `auth.py`: Authentication and authorization
- `config.py`: Application configuration
- `static/`: CSS and JavaScript files
- `templates/`: HTML templates

## Database Schema

- **Users Table**
  - id, username, password, email, full_name, role, created_at

- **Results Table**
  - id, student_id, subject, marks, grade, semester, academic_year, created_by, created_at, updated_at

## Technologies Used

- **Backend**: Python Flask
- **Database**: SQLite
- **Frontend**: HTML, CSS, JavaScript, Bootstrap
- **Charts**: Chart.js

## License

This project is available for your use and modification.

## About

This Result Management System was designed to facilitate easy recording, management, and viewing of student academic results. It provides role-based access for administrators, teachers, and students with appropriate permissions for each user type.
